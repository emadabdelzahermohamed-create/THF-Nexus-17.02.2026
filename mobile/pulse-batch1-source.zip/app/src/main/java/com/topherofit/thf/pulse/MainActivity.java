package com.topherofit.thf.pulse;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.util.Locale;
import org.json.JSONArray;
import org.json.JSONObject;

public final class MainActivity extends Activity implements SensorEventListener {
    private static final String PREFS = "thf_pulse_local";
    private static final int REQ_ACTIVITY = 701;
    private WebView web;
    private SharedPreferences prefs;
    private SensorManager sensorManager;
    private Sensor stepSensor;
    private float absoluteSteps = -1f;
    private float sessionBaseline = -1f;
    private TextToSpeech tts;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        sensorManager = (SensorManager)getSystemService(Context.SENSOR_SERVICE);
        if (sensorManager != null) stepSensor = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER);
        tts = new TextToSpeech(this, status -> { if (status == TextToSpeech.SUCCESS) tts.setLanguage(new Locale("ar", "EG")); });
        configureWebView();
        setContentView(web);
        web.loadUrl("file:///android_asset/pulse/index.html");
    }

    private void configureWebView() {
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setMediaPlaybackRequiresUserGesture(false);
        web.addJavascriptInterface(new PulseBridge(), "PulseNative");
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                String scheme = u.getScheme() == null ? "" : u.getScheme().toLowerCase(Locale.ROOT);
                if ("file".equals(scheme)) return false;
                return true;
            }
        });
    }

    private boolean hasActivityPermission() {
        return Build.VERSION.SDK_INT < 29 || checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION) == PackageManager.PERMISSION_GRANTED;
    }

    private boolean isOnline() {
        ConnectivityManager cm=(ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null) return false;
        Network n = cm.getActiveNetwork();
        if (n == null) return false;
        NetworkCapabilities c = cm.getNetworkCapabilities(n);
        return c != null && c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) && c.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED);
    }

    private boolean validPersistentHttps(String value) {
        if (value == null || value.trim().isEmpty()) return false;
        try {
            Uri u = Uri.parse(value.trim());
            String host = u.getHost() == null ? "" : u.getHost().toLowerCase(Locale.ROOT);
            if (!"https".equalsIgnoreCase(u.getScheme()) || host.isEmpty() || u.getUserInfo()!=null) return false;
            String[] banned = {"trycloudflare.com", "ngrok-free.app", "ngrok.io", "localhost", "127.0.0.1", ".local"};
            for (String b : banned) if (host.equals(b) || host.endsWith("."+b)) return false;
            return true;
        } catch (Exception ignored) { return false; }
    }

    @Override protected void onResume() {
        super.onResume();
        if (stepSensor != null && hasActivityPermission()) sensorManager.registerListener(this, stepSensor, SensorManager.SENSOR_DELAY_NORMAL);
    }

    @Override protected void onPause() {
        if (sensorManager != null) sensorManager.unregisterListener(this);
        super.onPause();
    }

    @Override protected void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        if (web != null) web.destroy();
        super.onDestroy();
    }

    @Override public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_STEP_COUNTER && event.values.length > 0) absoluteSteps = event.values[0];
    }
    @Override public void onAccuracyChanged(Sensor sensor, int accuracy) {}

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_ACTIVITY && web != null) {
            boolean ok = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            web.evaluateJavascript("window.dispatchEvent(new CustomEvent('thf:activity-permission',{detail:{granted:"+ok+"}}));", null);
            if (ok && stepSensor != null) sensorManager.registerListener(this, stepSensor, SensorManager.SENSOR_DELAY_NORMAL);
        }
    }

    public final class PulseBridge {
        @JavascriptInterface public String status() {
            try {
                JSONObject o = new JSONObject();
                String endpoint = BuildConfig.THF_BASE_URL == null ? "" : BuildConfig.THF_BASE_URL.trim();
                o.put("mode", "offline_first");
                o.put("version", BuildConfig.VERSION_NAME);
                o.put("package", BuildConfig.APPLICATION_ID);
                o.put("online", isOnline());
                o.put("syncConfigured", validPersistentHttps(endpoint));
                o.put("stepSensorAvailable", stepSensor != null);
                o.put("activityPermission", hasActivityPermission());
                o.put("sessionSteps", sessionSteps());
                return o.toString();
            } catch (Exception e) { return "{\"mode\":\"offline_first\"}"; }
        }

        @JavascriptInterface public void requestActivityPermission() {
            if (Build.VERSION.SDK_INT < 29 || hasActivityPermission()) {
                runOnUiThread(() -> web.evaluateJavascript("window.dispatchEvent(new CustomEvent('thf:activity-permission',{detail:{granted:true}}));", null));
                return;
            }
            runOnUiThread(() -> requestPermissions(new String[]{Manifest.permission.ACTIVITY_RECOGNITION}, REQ_ACTIVITY));
        }

        @JavascriptInterface public void beginStepSession() {
            if (absoluteSteps >= 0) sessionBaseline = absoluteSteps;
            else sessionBaseline = -1f;
            prefs.edit().putFloat("step_baseline", sessionBaseline).apply();
        }

        @JavascriptInterface public int sessionSteps() {
            float baseline = sessionBaseline >= 0 ? sessionBaseline : prefs.getFloat("step_baseline", -1f);
            if (absoluteSteps < 0 || baseline < 0) return 0;
            return Math.max(0, Math.round(absoluteSteps - baseline));
        }

        @JavascriptInterface public void speak(String text, String languageTag) {
            if (text == null || text.isBlank() || tts == null) return;
            runOnUiThread(() -> {
                try {
                    Locale locale = languageTag != null && languageTag.toLowerCase(Locale.ROOT).startsWith("ar") ? new Locale("ar","EG") : Locale.US;
                    tts.setLanguage(locale);
                    tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "thf-pulse");
                } catch (Exception ignored) {}
            });
        }

        @JavascriptInterface public String saveSummary(String json) {
            try {
                JSONArray arr = new JSONArray(prefs.getString("summaries", "[]"));
                JSONObject item = new JSONObject(json == null ? "{}" : json);
                item.put("savedAt", System.currentTimeMillis());
                arr.put(item);
                while (arr.length() > 60) {
                    JSONArray next = new JSONArray();
                    for (int i=1;i<arr.length();i++) next.put(arr.get(i));
                    arr = next;
                }
                prefs.edit().putString("summaries", arr.toString()).apply();
                return "{\"saved\":true}";
            } catch (Exception e) { return "{\"saved\":false}"; }
        }

        @JavascriptInterface public String readSummaries() { return prefs.getString("summaries", "[]"); }
        @JavascriptInterface public void setPref(String key, String value) { if (key != null) prefs.edit().putString("web_"+key, value == null ? "" : value).apply(); }
        @JavascriptInterface public String getPref(String key) { return key == null ? "" : prefs.getString("web_"+key, ""); }
    }
}
