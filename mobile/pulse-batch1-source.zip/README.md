# THF Pulse 4.2.0 Batch 1
Offline-first Android phone build. The application opens the packaged local workout runtime by default and never blocks on an external endpoint. Optional online sync can be injected at build time using `-PTHF_BASE_URL=https://...`, and common temporary hosts are rejected at runtime.

Local features: workout catalogue, animated human coach, timer, rep counter, Arabic voice cue bridge, local progress/history, Android step-counter bridge, activity permission flow, accessibility-safe phone layout, API 36.
