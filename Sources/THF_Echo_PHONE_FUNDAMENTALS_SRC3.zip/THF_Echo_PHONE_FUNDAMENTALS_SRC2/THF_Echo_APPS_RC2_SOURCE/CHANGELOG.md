# Changelog
## 2.0.0
- Rebrand standalone Media as THF Echo.
- Keep Stories/Shorts/Long Video/Image/Audio/Live and FFmpeg HLS foundation.
- Add public professional/ambassador/gym profiles, follows and deep-link directory.
- Add direct chat, block/mute/report, privacy/data saver, WebRTC call client + WebSocket signaling.
- Add media MIME/extension upload guard and protected-context ads.
- Keep creator payouts as signed economy events; no direct token mint.
