# THF Echo 2.0 — Media & Communications Standalone

تطبيق ميديا مستقل ببايثون/FastAPI. لا يعتمد على بقية تطبيقات THF؛ الرابط الخارجي الوحيد الاختياري هو Economy API.

## الخصائص
- Stories تنتهي بعد 24 ساعة.
- Shorts، فيديو طويل، صور وصوت.
- رفع ملفات streaming إلى تخزين VPS المحلي مع حد حجم مضبوط من ENV.
- Comments وReactions وViews.
- Live room lifecycle كأساس للـWebRTC/RTMP القادم.
- FFmpeg HLS 720p عند توفر `ffmpeg`.
- Moderation queue ولوحة Admin منفصلة.
- Ads Control Plane: campaign/placement/frequency cap/min interval/analytics.
- اقتصاد creators قابل للربط عبر أحداث موقعة، وليس mint داخل تطبيق الميديا.

## تشغيل
```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
set -a; source .env; set +a
pytest -q
./run.sh
```
افتح `http://localhost:8102`.

## THF Echo 2.0
- الاسم الجديد المستقل: **THF Echo**.
- ملفات عامة موثقة للمدربين والأطباء والجيمات وسفراء التعلم كي تصل إليها التطبيقات الأخرى كرابط فقط.
- محادثات مباشرة، متابعة، Block/Mute/Report، إعدادات خصوصية وData Saver.
- مكالمات صوت/فيديو WebRTC حقيقية في العميل مع WebSocket signaling في FastAPI. الاتصال عبر شبكات NAT المختلفة يحتاج TURN في الإنتاج.
- Stories/Shorts/Long Video/Images/Audio/Live من النسخة الأساسية محفوظة ومطورة.
- الإعلانات لا تظهر داخل المحادثات الخاصة أو المكالمات أو شاشات الأمان، ولا تستخدم الصحة/الدين للاستهداف.
- الرسائل النصية في هذه النسخة مخزنة على الخادم؛ لا ندعي E2EE قبل تنفيذ عميل تشفير طرفي كامل.
