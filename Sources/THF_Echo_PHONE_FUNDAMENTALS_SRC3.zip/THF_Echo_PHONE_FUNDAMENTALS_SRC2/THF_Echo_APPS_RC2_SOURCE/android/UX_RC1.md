# THF Apps RC1 native UX

Adds loading progress, secure offline/error/retry states, native Data Saver, Reduce Motion, High Contrast and text zoom settings, plus a `thf:native-prefs` web event. No new permissions.
