# THF Echo native host — APPS-RC2 i18n/RTL checkpoint

Native error/settings chrome now uses Android resources with English + 19 translated locale sets (20 total) and `supportsRtl=true`. Locale is also forwarded to the web product through `THF_NATIVE_PREFS`.

This is source-level readiness only. Full 20-language product content, layout quality, TalkBack, touch/orientation and device acceptance remain release gates.
