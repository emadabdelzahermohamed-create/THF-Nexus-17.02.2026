from __future__ import annotations

import hashlib, hmac, json, os, sqlite3, time, uuid
from contextlib import contextmanager
from pathlib import Path
from typing import Any
import httpx

DB_PATH=Path(os.getenv("DB_PATH","./data/media.db"))
MEDIA_ROOT=Path(os.getenv("MEDIA_ROOT","./data/media"))
ADMIN_KEY=os.getenv("ADMIN_KEY","").strip()
MAX_UPLOAD_MB=int(os.getenv("MAX_UPLOAD_MB","256"))
ECONOMY_URL=os.getenv("ECONOMY_URL","").rstrip("/")
ECONOMY_SERVICE=os.getenv("ECONOMY_SERVICE","media")
ECONOMY_SERVICE_SECRET=os.getenv("ECONOMY_SERVICE_SECRET","").strip()

@contextmanager
def db():
    DB_PATH.parent.mkdir(parents=True,exist_ok=True); MEDIA_ROOT.mkdir(parents=True,exist_ok=True)
    conn=sqlite3.connect(DB_PATH); conn.row_factory=sqlite3.Row
    try:
        yield conn; conn.commit()
    finally: conn.close()

def now(): return int(time.time())

def emit_economy_event(*,user_id:str,event_type:str,amount:float,asset:str="CREDITS",metadata:dict[str,Any]|None=None):
    payload={"event_id":str(uuid.uuid4()),"service":ECONOMY_SERVICE,"user_id":user_id,"event_type":event_type,"asset":asset,"amount":float(amount),"metadata":metadata or {},"ts":now()}
    raw=json.dumps(payload,sort_keys=True,separators=(",",":")).encode(); sig=hmac.new(ECONOMY_SERVICE_SECRET.encode(),raw,hashlib.sha256).hexdigest() if ECONOMY_SERVICE_SECRET else ""; status="pending"; gateway={}
    if ECONOMY_URL.startswith("https://") and ECONOMY_SERVICE_SECRET:
        try:
            r=httpx.post(f"{ECONOMY_URL}/events",json=payload,headers={"X-THF-Signature":sig},timeout=4); r.raise_for_status(); gateway=r.json(); status="sent"
        except Exception as exc: gateway={"error":type(exc).__name__}
    with db() as conn: conn.execute("INSERT INTO economy_outbox VALUES(?,?,?,?)",(payload['event_id'],json.dumps(payload,ensure_ascii=False),status,now()))
    return {"status":status,"gateway":gateway,"event":payload}
