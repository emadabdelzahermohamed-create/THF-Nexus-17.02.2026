from __future__ import annotations

"""THF Echo 2.0 social, chat, privacy and WebRTC signaling layer.

المكالمات تستخدم WebRTC في العميل وWebSocket للإشارات فقط؛ الخادم لا يسجل الصوت/الفيديو.
TURN يتم تمريره من إعدادات البيئة عند توفره. لا ندّعي تشفيراً طرفياً للرسائل النصية.
"""

import hashlib
import json
import os
import uuid
from collections import defaultdict
from typing import Any

from fastapi import APIRouter, Header, HTTPException, Request, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates

from .core import ADMIN_KEY, db, now

router = APIRouter()
BASE = os.path.dirname(os.path.dirname(__file__))
templates = Jinja2Templates(directory=os.path.join(BASE, "templates"))
ICE_SERVERS_JSON = os.getenv("ICE_SERVERS_JSON", '[{"urls":["stun:stun.l.google.com:19302"]}]')

CALL_PEERS: dict[str, dict[str, WebSocket]] = defaultdict(dict)


def init_social_db() -> None:
    with db() as c:
        c.executescript(
            """
            CREATE TABLE IF NOT EXISTS profiles(
              user_id TEXT PRIMARY KEY, handle TEXT UNIQUE, display_name TEXT, bio TEXT, category TEXT,
              city TEXT, avatar_url TEXT, verified INTEGER DEFAULT 0, private INTEGER DEFAULT 0, created_at INTEGER
            );
            CREATE TABLE IF NOT EXISTS follows(
              follower_id TEXT, followee_id TEXT, created_at INTEGER, PRIMARY KEY(follower_id,followee_id)
            );
            CREATE TABLE IF NOT EXISTS conversations(
              id TEXT PRIMARY KEY, kind TEXT, title TEXT, direct_key TEXT UNIQUE, created_at INTEGER
            );
            CREATE TABLE IF NOT EXISTS conversation_members(
              conversation_id TEXT, user_id TEXT, joined_at INTEGER, PRIMARY KEY(conversation_id,user_id)
            );
            CREATE TABLE IF NOT EXISTS chat_messages(
              id TEXT PRIMARY KEY, conversation_id TEXT, sender_id TEXT, body TEXT, created_at INTEGER,
              edited_at INTEGER, deleted INTEGER DEFAULT 0
            );
            CREATE TABLE IF NOT EXISTS user_blocks(
              blocker_id TEXT, blocked_id TEXT, created_at INTEGER, PRIMARY KEY(blocker_id,blocked_id)
            );
            CREATE TABLE IF NOT EXISTS user_mutes(
              user_id TEXT, muted_id TEXT, created_at INTEGER, PRIMARY KEY(user_id,muted_id)
            );
            CREATE TABLE IF NOT EXISTS safety_reports(
              id INTEGER PRIMARY KEY AUTOINCREMENT, reporter_id TEXT, target_type TEXT, target_id TEXT,
              reason TEXT, details TEXT, status TEXT DEFAULT 'open', created_at INTEGER
            );
            CREATE TABLE IF NOT EXISTS link_privacy(
              user_id TEXT PRIMARY KEY, data_saver INTEGER DEFAULT 0, autoplay INTEGER DEFAULT 1,
              allow_calls TEXT DEFAULT 'following', allow_messages TEXT DEFAULT 'following',
              discoverable INTEGER DEFAULT 1, personalized_ads INTEGER DEFAULT 0, updated_at INTEGER
            );
            CREATE TABLE IF NOT EXISTS call_rooms(
              id TEXT PRIMARY KEY, owner_id TEXT, mode TEXT, status TEXT, created_at INTEGER, ended_at INTEGER
            );
            """
        )
        # الملفات العامة المشتركة تُزرع بطريقة idempotent حتى تظل الروابط العميقة من
        # Pulse وQuest وMarket صالحة بعد أي ترقية أو قاعدة بيانات موجودة مسبقاً.
        rows = [
            ("coach-omar", "coach-omar", "كابتن عمر", "مدرب قوة ولياقة — صفحة التواصل العامة.", "trainer", "Cairo", "", 0, 0, now()),
            ("dr-salma", "dr-salma", "د. سلمى", "طب رياضي — المعلومات العامة فقط، الاستشارة تحتاج موافقة الطرفين.", "doctor", "Giza", "", 0, 0, now()),
            ("physio-nour", "physio-nour", "نور", "علاج طبيعي رياضي وتأهيل حركي.", "physio", "Alexandria", "", 0, 0, now()),
            ("hero-gym-cairo", "hero-gym-cairo", "Hero Gym Cairo", "جيم شريك على THF.", "gym", "Cairo", "", 0, 0, now()),
            ("ambassador-lina", "ambassador-lina", "لينا — سفيرة تعلم", "سفيرة لمجتمع التعلم والمسابقات.", "learning_ambassador", "Cairo", "", 0, 0, now()),
            ("ambassador-yousef", "ambassador-yousef", "يوسف — سفير تعلم", "سفير للمسابقات العلمية والتعلم بالمشروعات.", "learning_ambassador", "Alexandria", "", 0, 0, now()),
            ("thf-official", "thf-official", "THF Official", "الحساب الرسمي لخدمات ومنتجات THF.", "brand", "", "", 1, 0, now()),
        ]
        c.executemany("INSERT OR IGNORE INTO profiles(user_id,handle,display_name,bio,category,city,avatar_url,verified,private,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)", rows)


def _profile(c, handle: str):
    return c.execute("SELECT * FROM profiles WHERE handle=?", (handle,)).fetchone()


@router.get("/u/{handle}", response_class=HTMLResponse)
def profile_page(request: Request, handle: str, viewer: str = "demo"):
    with db() as c:
        p = _profile(c, handle)
        if not p: raise HTTPException(404, "profile not found")
        posts = c.execute("SELECT id,type,title,caption,created_at,view_count,like_count,comment_count FROM media WHERE user_id=? AND status='published' AND privacy='public' ORDER BY created_at DESC LIMIT 30", (p["user_id"],)).fetchall()
        following = bool(c.execute("SELECT 1 FROM follows WHERE follower_id=? AND followee_id=?", (viewer, p["user_id"])).fetchone())
    return templates.TemplateResponse(request, "profile.html", {"profile": p, "posts": posts, "viewer": viewer, "following": following})


@router.post("/api/profiles")
def upsert_profile(payload: dict[str, Any]) -> dict[str, Any]:
    uid = str(payload.get("user_id", "demo"))[:120]
    handle = str(payload.get("handle", uid)).strip().lower()[:60]
    if not handle or any(ch not in "abcdefghijklmnopqrstuvwxyz0123456789-_" for ch in handle): raise HTTPException(400, "invalid handle")
    with db() as c:
        c.execute("INSERT INTO profiles(user_id,handle,display_name,bio,category,city,avatar_url,verified,private,created_at) VALUES(?,?,?,?,?,?,?,?,?,?) ON CONFLICT(user_id) DO UPDATE SET handle=excluded.handle,display_name=excluded.display_name,bio=excluded.bio,category=excluded.category,city=excluded.city,avatar_url=excluded.avatar_url,private=excluded.private", (uid, handle, str(payload.get("display_name", handle))[:100], str(payload.get("bio", ""))[:800], str(payload.get("category", "member"))[:40], str(payload.get("city", ""))[:80], str(payload.get("avatar_url", ""))[:500], 0, 1 if payload.get("private") else 0, now()))
    return {"saved": True, "profile_url": f"/u/{handle}"}


@router.post("/api/follow/{target_id}")
def follow(target_id: str, payload: dict[str, Any]) -> dict[str, Any]:
    uid = str(payload.get("user_id", "demo"))
    if uid == target_id: raise HTTPException(400, "cannot follow self")
    with db() as c:
        if c.execute("SELECT 1 FROM user_blocks WHERE blocker_id=? AND blocked_id=?", (target_id, uid)).fetchone(): raise HTTPException(403, "blocked")
        c.execute("INSERT OR IGNORE INTO follows(follower_id,followee_id,created_at) VALUES(?,?,?)", (uid, target_id, now()))
    return {"following": True}


def _direct_key(a: str, b: str) -> str:
    return hashlib.sha256("\0".join(sorted((a, b))).encode()).hexdigest()


@router.post("/api/chats/direct")
def direct_chat(payload: dict[str, Any]) -> dict[str, Any]:
    a = str(payload.get("user_id", "demo")); b = str(payload.get("target_id", ""))
    if not b or a == b: raise HTTPException(400, "invalid target")
    key = _direct_key(a, b)
    with db() as c:
        if c.execute("SELECT 1 FROM user_blocks WHERE (blocker_id=? AND blocked_id=?) OR (blocker_id=? AND blocked_id=?)", (a,b,b,a)).fetchone(): raise HTTPException(403, "chat blocked")
        row = c.execute("SELECT id FROM conversations WHERE direct_key=?", (key,)).fetchone()
        if row: cid = row[0]
        else:
            cid = str(uuid.uuid4()); c.execute("INSERT INTO conversations(id,kind,title,direct_key,created_at) VALUES(?,?,?,?,?)", (cid,"direct","",key,now())); c.executemany("INSERT INTO conversation_members(conversation_id,user_id,joined_at) VALUES(?,?,?)", [(cid,a,now()),(cid,b,now())])
    return {"conversation_id": cid, "url": f"/chat/{cid}?user={a}"}


@router.get("/chat/{conversation_id}", response_class=HTMLResponse)
def chat_page(request: Request, conversation_id: str, user: str = "demo"):
    with db() as c:
        if not c.execute("SELECT 1 FROM conversation_members WHERE conversation_id=? AND user_id=?", (conversation_id,user)).fetchone(): raise HTTPException(403, "not a member")
        messages = c.execute("SELECT * FROM chat_messages WHERE conversation_id=? ORDER BY created_at DESC LIMIT 100", (conversation_id,)).fetchall()[::-1]
    return templates.TemplateResponse(request, "chat.html", {"conversation_id": conversation_id, "user": user, "messages": messages})


@router.get("/api/chats/{conversation_id}/messages")
def messages(conversation_id: str, user_id: str = "demo", after: int = 0) -> dict[str, Any]:
    with db() as c:
        if not c.execute("SELECT 1 FROM conversation_members WHERE conversation_id=? AND user_id=?", (conversation_id,user_id)).fetchone(): raise HTTPException(403, "not a member")
        rows = c.execute("SELECT * FROM chat_messages WHERE conversation_id=? AND created_at>=? ORDER BY created_at LIMIT 200", (conversation_id,after)).fetchall()
    return {"items": [{**dict(r), "body": "" if r["deleted"] else r["body"]} for r in rows]}


@router.post("/api/chats/{conversation_id}/messages")
def send_message(conversation_id: str, payload: dict[str, Any]) -> dict[str, Any]:
    uid = str(payload.get("user_id", "demo")); body = str(payload.get("body", "")).strip()
    if not body or len(body) > 2000: raise HTTPException(400, "invalid message")
    with db() as c:
        if not c.execute("SELECT 1 FROM conversation_members WHERE conversation_id=? AND user_id=?", (conversation_id,uid)).fetchone(): raise HTTPException(403, "not a member")
        others = [r[0] for r in c.execute("SELECT user_id FROM conversation_members WHERE conversation_id=? AND user_id<>?", (conversation_id,uid))]
        for other in others:
            if c.execute("SELECT 1 FROM user_blocks WHERE blocker_id=? AND blocked_id=?", (other,uid)).fetchone(): raise HTTPException(403, "recipient blocked sender")
        mid = str(uuid.uuid4()); c.execute("INSERT INTO chat_messages(id,conversation_id,sender_id,body,created_at) VALUES(?,?,?,?,?)", (mid,conversation_id,uid,body,now()))
    return {"sent": True, "message_id": mid, "e2ee": False, "privacy_note": "server_stored_message"}


@router.post("/api/safety/block/{target_id}")
def block(target_id: str, payload: dict[str, Any]) -> dict[str, Any]:
    uid = str(payload.get("user_id", "demo"))
    with db() as c: c.execute("INSERT OR IGNORE INTO user_blocks(blocker_id,blocked_id,created_at) VALUES(?,?,?)", (uid,target_id,now()))
    return {"blocked": True}


@router.post("/api/safety/mute/{target_id}")
def mute(target_id: str, payload: dict[str, Any]) -> dict[str, Any]:
    uid = str(payload.get("user_id", "demo"))
    with db() as c: c.execute("INSERT OR IGNORE INTO user_mutes(user_id,muted_id,created_at) VALUES(?,?,?)", (uid,target_id,now()))
    return {"muted": True}


@router.post("/api/safety/report")
def report(payload: dict[str, Any]) -> dict[str, Any]:
    uid = str(payload.get("user_id", "demo")); reason = str(payload.get("reason", "other"))[:80]
    with db() as c:
        cur = c.execute("INSERT INTO safety_reports(reporter_id,target_type,target_id,reason,details,status,created_at) VALUES(?,?,?,?,?,'open',?)", (uid,str(payload.get("target_type","user"))[:30],str(payload.get("target_id",""))[:120],reason,str(payload.get("details",""))[:1000],now()))
    return {"reported": True, "report_id": cur.lastrowid}


@router.put("/api/privacy/{user_id}")
def privacy(user_id: str, payload: dict[str, Any]) -> dict[str, Any]:
    allow_calls = str(payload.get("allow_calls", "following")); allow_messages = str(payload.get("allow_messages", "following"))
    if allow_calls not in {"everyone","following","nobody"} or allow_messages not in {"everyone","following","nobody"}: raise HTTPException(400, "bad privacy value")
    with db() as c:
        c.execute("INSERT INTO link_privacy(user_id,data_saver,autoplay,allow_calls,allow_messages,discoverable,personalized_ads,updated_at) VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(user_id) DO UPDATE SET data_saver=excluded.data_saver,autoplay=excluded.autoplay,allow_calls=excluded.allow_calls,allow_messages=excluded.allow_messages,discoverable=excluded.discoverable,personalized_ads=excluded.personalized_ads,updated_at=excluded.updated_at", (user_id,1 if payload.get("data_saver") else 0,1 if payload.get("autoplay",True) else 0,allow_calls,allow_messages,1 if payload.get("discoverable",True) else 0,1 if payload.get("personalized_ads") else 0,now()))
    return {"saved": True, "sensitive_health_or_religion_used_for_ads": False}


@router.get("/api/playback-policy/{user_id}")
def playback_policy(user_id: str) -> dict[str, Any]:
    with db() as c: r = c.execute("SELECT * FROM link_privacy WHERE user_id=?", (user_id,)).fetchone()
    saver = bool(r and r["data_saver"])
    return {"data_saver": saver, "autoplay": bool(r["autoplay"]) if r else True, "preferred_max_height": 360 if saver else 1080, "preload": "metadata" if saver else "auto", "stories_prefetch": 1 if saver else 5}


@router.post("/api/calls")
def create_call(payload: dict[str, Any]) -> dict[str, Any]:
    owner = str(payload.get("owner_id", "demo")); mode = str(payload.get("mode", "video"))
    if mode not in {"audio","video"}: raise HTTPException(400, "bad mode")
    rid = str(uuid.uuid4())
    with db() as c: c.execute("INSERT INTO call_rooms(id,owner_id,mode,status,created_at) VALUES(?,?,?,?,?)", (rid,owner,mode,"waiting",now()))
    return {"room_id": rid, "url": f"/call/{rid}?user={owner}", "mode": mode}


@router.get("/call/{room_id}", response_class=HTMLResponse)
def call_page(request: Request, room_id: str, user: str = "demo"):
    with db() as c:
        r = c.execute("SELECT * FROM call_rooms WHERE id=?", (room_id,)).fetchone()
    if not r: raise HTTPException(404, "call room not found")
    return templates.TemplateResponse(request, "call.html", {"room": r, "user": user})


@router.get("/api/calls/ice")
def ice_config() -> dict[str, Any]:
    try: servers = json.loads(ICE_SERVERS_JSON)
    except Exception: servers = []
    return {"iceServers": servers, "turn_required_for_reliable_cross_nat": True}


@router.websocket("/ws/calls/{room_id}/{user_id}")
async def call_signal(ws: WebSocket, room_id: str, user_id: str):
    await ws.accept()
    if len(CALL_PEERS[room_id]) >= 4:
        await ws.send_json({"type":"error","message":"room_full"}); await ws.close(); return
    CALL_PEERS[room_id][user_id] = ws
    with db() as c: c.execute("UPDATE call_rooms SET status='active' WHERE id=?", (room_id,))
    try:
        for peer_id, peer in list(CALL_PEERS[room_id].items()):
            if peer_id != user_id: await peer.send_json({"type":"peer-joined","user_id":user_id})
        while True:
            msg = await ws.receive_json(); msg["from"] = user_id
            target = str(msg.get("to", ""))
            if target and target in CALL_PEERS[room_id]: await CALL_PEERS[room_id][target].send_json(msg)
            else:
                for peer_id, peer in list(CALL_PEERS[room_id].items()):
                    if peer_id != user_id: await peer.send_json(msg)
    except WebSocketDisconnect:
        pass
    finally:
        CALL_PEERS[room_id].pop(user_id, None)
        for peer in list(CALL_PEERS[room_id].values()):
            try: await peer.send_json({"type":"peer-left","user_id":user_id})
            except Exception: pass
        if not CALL_PEERS[room_id]:
            CALL_PEERS.pop(room_id, None)
            with db() as c: c.execute("UPDATE call_rooms SET status='ended',ended_at=? WHERE id=?", (now(),room_id))


@router.get("/api/ads/next-safe")
def next_safe_ad(user_id: str = "demo", placement: str = "feed_native", context: str = "feed") -> dict[str, Any]:
    if context in {"private_chat","call","upload","moderation","safety_report","child_focus"}:
        return {"ad": None, "reason": "protected_context"}
    with db() as c:
        campaigns = c.execute("SELECT * FROM ad_campaigns WHERE enabled=1 AND placement=? ORDER BY revenue DESC,clicks DESC,id", (placement,)).fetchall()
        for camp in campaigns:
            since = now()-86400
            count = c.execute("SELECT COUNT(*) FROM ad_events WHERE campaign_id=? AND user_id=? AND kind='impression' AND created_at>=?", (camp["id"],user_id,since)).fetchone()[0]
            last = c.execute("SELECT COALESCE(MAX(created_at),0) FROM ad_events WHERE campaign_id=? AND user_id=? AND kind='impression'", (camp["id"],user_id)).fetchone()[0]
            if count>=camp["frequency_cap_day"] or now()-last<camp["min_interval_sec"]: continue
            c.execute("INSERT INTO ad_events(campaign_id,user_id,kind,created_at) VALUES(?,?,?,?)", (camp["id"],user_id,"impression",now())); c.execute("UPDATE ad_campaigns SET impressions=impressions+1 WHERE id=?",(camp["id"],))
            return {"ad":{"id":camp["id"],"text":camp["creative_text"],"url":camp["landing_url"]},"sensitive_targeting":False}
    return {"ad":None}


@router.post("/api/admin/profiles/{user_id}/verify")
def verify_profile(user_id: str, payload: dict[str, Any], x_admin_key: str = Header(default="")) -> dict[str, Any]:
    if not ADMIN_KEY or x_admin_key != ADMIN_KEY: raise HTTPException(403,"forbidden")
    with db() as c: c.execute("UPDATE profiles SET verified=? WHERE user_id=?",(1 if payload.get("verified",True) else 0,user_id))
    return {"ok":True}


@router.post("/api/admin/ads")
def create_ad(payload: dict[str, Any], x_admin_key: str = Header(default="")) -> dict[str, Any]:
    if not ADMIN_KEY or x_admin_key != ADMIN_KEY: raise HTTPException(403,"forbidden")
    placement = str(payload.get("placement","feed_native"))
    if placement not in {"feed_native","story_interstitial","video_pre","video_mid","search_native","creator_sponsor"}: raise HTTPException(400,"bad placement")
    with db() as c:
        cur=c.execute("INSERT INTO ad_campaigns(name,placement,cpm,cpc,enabled,frequency_cap_day,min_interval_sec,landing_url,creative_text) VALUES(?,?,?,?,?,?,?,?,?)",(str(payload.get("name","Campaign"))[:120],placement,float(payload.get("cpm",0)),float(payload.get("cpc",0)),1,int(payload.get("frequency_cap_day",3)),int(payload.get("min_interval_sec",180)),str(payload.get("landing_url",""))[:500],str(payload.get("creative_text",""))[:500]))
    return {"created":True,"id":cur.lastrowid}


@router.get("/api/admin/social-safety")
def admin_safety(x_admin_key: str = Header(default="")) -> dict[str, Any]:
    if not ADMIN_KEY or x_admin_key != ADMIN_KEY: raise HTTPException(403,"forbidden")
    with db() as c:
        return {"reports":[dict(r) for r in c.execute("SELECT * FROM safety_reports WHERE status='open' ORDER BY created_at DESC LIMIT 200")],"profiles":[dict(r) for r in c.execute("SELECT * FROM profiles ORDER BY verified DESC,created_at DESC LIMIT 200")],"active_calls":c.execute("SELECT COUNT(*) FROM call_rooms WHERE status IN ('waiting','active')").fetchone()[0]}

@router.post("/api/admin/safety-reports/{report_id}/status")
def admin_report_status(report_id: int,payload: dict[str, Any],x_admin_key: str=Header(default="")) -> dict[str, Any]:
    if not ADMIN_KEY or x_admin_key!=ADMIN_KEY: raise HTTPException(403,"forbidden")
    status=str(payload.get("status","closed"))
    if status not in {"open","reviewing","closed","actioned"}: raise HTTPException(400,"bad status")
    with db() as c:c.execute("UPDATE safety_reports SET status=? WHERE id=?",(status,report_id))
    return {"ok":True}

@router.get("/api/privacy-summary/{user_id}")
def privacy_summary(user_id: str) -> dict[str, Any]:
    """ملخص سياسة المستخدم دون كشف الرسائل أو بيانات خاصة لطرف آخر."""
    with db() as c:
        p=c.execute("SELECT data_saver,autoplay,allow_calls,allow_messages,discoverable,personalized_ads FROM link_privacy WHERE user_id=?",(user_id,)).fetchone()
        blocked=c.execute("SELECT COUNT(*) FROM user_blocks WHERE blocker_id=?",(user_id,)).fetchone()[0]
    return {"settings":dict(p) if p else {"data_saver":0,"autoplay":1,"allow_calls":"following","allow_messages":"following","discoverable":1,"personalized_ads":0},"blocked_count":blocked,"sensitive_health_or_religion_used_for_ads":False,"message_storage":"server_stored_not_e2ee"}
