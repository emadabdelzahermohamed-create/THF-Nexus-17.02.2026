from __future__ import annotations

import json, mimetypes, os, shutil, subprocess, uuid
from pathlib import Path
from typing import Any
from contextlib import asynccontextmanager
from fastapi import BackgroundTasks, FastAPI, File, Form, Header, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse, HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel, Field

from .core import ADMIN_KEY, MAX_UPLOAD_MB, MEDIA_ROOT, db, emit_economy_event, now
from .social import router as social_router, init_social_db

BASE=Path(__file__).resolve().parent.parent
@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    init_social_db()
    yield

app=FastAPI(title="THF Echo",version="2.1.0-stage16o",lifespan=lifespan)
app.mount("/static",StaticFiles(directory=BASE/'static'),name='static')
app.include_router(social_router)
templates=Jinja2Templates(directory=BASE/'templates')


def init_db():
    with db() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS media(id TEXT PRIMARY KEY,user_id TEXT,type TEXT,title TEXT,caption TEXT,privacy TEXT,file_path TEXT,poster_path TEXT,status TEXT,created_at INTEGER,expires_at INTEGER,duration_sec REAL DEFAULT 0,view_count INTEGER DEFAULT 0,like_count INTEGER DEFAULT 0,comment_count INTEGER DEFAULT 0,transcode_status TEXT DEFAULT 'original');
        CREATE TABLE IF NOT EXISTS reactions(id INTEGER PRIMARY KEY AUTOINCREMENT,media_id TEXT,user_id TEXT,kind TEXT,created_at INTEGER,UNIQUE(media_id,user_id,kind));
        CREATE TABLE IF NOT EXISTS comments(id INTEGER PRIMARY KEY AUTOINCREMENT,media_id TEXT,user_id TEXT,body TEXT,status TEXT DEFAULT 'visible',created_at INTEGER);
        CREATE TABLE IF NOT EXISTS live_rooms(id TEXT PRIMARY KEY,owner_id TEXT,title TEXT,status TEXT,created_at INTEGER,ended_at INTEGER,viewer_count INTEGER DEFAULT 0);
        CREATE TABLE IF NOT EXISTS ad_campaigns(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,placement TEXT,cpm REAL DEFAULT 0,cpc REAL DEFAULT 0,enabled INTEGER DEFAULT 1,frequency_cap_day INTEGER DEFAULT 3,min_interval_sec INTEGER DEFAULT 180,landing_url TEXT,creative_text TEXT,impressions INTEGER DEFAULT 0,clicks INTEGER DEFAULT 0,revenue REAL DEFAULT 0);
        CREATE TABLE IF NOT EXISTS ad_events(id INTEGER PRIMARY KEY AUTOINCREMENT,campaign_id INTEGER,user_id TEXT,kind TEXT,revenue REAL DEFAULT 0,created_at INTEGER);
        CREATE TABLE IF NOT EXISTS moderation_queue(id INTEGER PRIMARY KEY AUTOINCREMENT,media_id TEXT,reason TEXT,status TEXT DEFAULT 'open',created_at INTEGER);
        CREATE TABLE IF NOT EXISTS creator_payouts(payout_id TEXT PRIMARY KEY,user_id TEXT,media_id TEXT,amount REAL,asset TEXT,created_at INTEGER);
        CREATE TABLE IF NOT EXISTS economy_outbox(event_id TEXT PRIMARY KEY,payload_json TEXT,status TEXT,created_at INTEGER);
        """)
        if c.execute("SELECT COUNT(*) FROM ad_campaigns").fetchone()[0]==0:
            c.execute("INSERT INTO ad_campaigns(name,placement,cpm,cpc,creative_text,landing_url) VALUES(?,?,?,?,?,?)",("THF Native Demo","feed_native",2.0,.08,"إعلان تجريبي أصلي غير مزعج","https://example.com"))

@app.get('/health')
def health(): return {'ok':True,'service':'THF Echo','version':'2.0.0','economy_service':'media','ffmpeg':shutil.which('ffmpeg') is not None}


def public_feed_rows(c):
    t=now()
    return c.execute("SELECT * FROM media WHERE status='published' AND privacy='public' AND (expires_at IS NULL OR expires_at>?) ORDER BY created_at DESC LIMIT 100",(t,)).fetchall()

@app.get('/',response_class=HTMLResponse)
def home(request:Request,user:str='demo'):
    with db() as c:
        feed=public_feed_rows(c); stories=[r for r in feed if r['type']=='story']; main=[r for r in feed if r['type']!='story']
    return templates.TemplateResponse(request, 'home.html', {'stories':stories,'feed':main,'user':user})

@app.post('/upload')
async def upload(user_id:str=Form('demo'),media_type:str=Form('video'),title:str=Form(''),caption:str=Form(''),privacy:str=Form('public'),file:UploadFile=File(...)):
    if media_type not in {'story','short','video','image','audio'}: raise HTTPException(400,'bad media type')
    if privacy not in {'public','private','unlisted'}: raise HTTPException(400,'bad privacy')
    # فلترة أولية للنوع والامتداد قبل التخزين. هذه ليست بديلاً عن malware/media scanning
    # في الإنتاج، لكنها تمنع رفع ملفات عشوائية على أنها وسائط في نسخة الـPilot.
    ext=Path(file.filename or '').suffix.lower()[:10]
    content_type=(file.content_type or '').lower()
    image_ext={'.jpg','.jpeg','.png','.webp','.gif'}
    video_ext={'.mp4','.webm','.mov','.m4v'}
    audio_ext={'.mp3','.wav','.m4a','.aac','.ogg','.opus','.flac'}
    if media_type=='image': allowed_ext=image_ext; allowed_prefix=('image/',)
    elif media_type=='audio': allowed_ext=audio_ext; allowed_prefix=('audio/',)
    elif media_type in {'video','short'}: allowed_ext=video_ext; allowed_prefix=('video/',)
    else:  # story may be either image or video
        allowed_ext=image_ext|video_ext; allowed_prefix=('image/','video/')
    if ext not in allowed_ext or not content_type.startswith(allowed_prefix):
        raise HTTPException(415,'media type/extension mismatch')
    mid=str(uuid.uuid4()); dst=MEDIA_ROOT/f"{mid}{ext}"
    size=0
    with dst.open('wb') as out:
        while chunk:=await file.read(1024*1024):
            size+=len(chunk)
            if size>MAX_UPLOAD_MB*1024*1024:
                out.close(); dst.unlink(missing_ok=True); raise HTTPException(413,'file too large')
            out.write(chunk)
    expires=now()+86400 if media_type=='story' else None
    with db() as c:
        c.execute("INSERT INTO media(id,user_id,type,title,caption,privacy,file_path,status,created_at,expires_at) VALUES(?,?,?,?,?,?,?,?,?,?)",(mid,user_id,media_type,title or file.filename or media_type,caption,privacy,str(dst),'published',now(),expires))
    return RedirectResponse(f"/?user={user_id}",303)

@app.get('/media/{media_id}')
def serve_media(media_id:str):
    with db() as c: r=c.execute("SELECT file_path FROM media WHERE id=? AND status='published'",(media_id,)).fetchone()
    if not r or not Path(r['file_path']).exists(): raise HTTPException(404,'not found')
    return FileResponse(r['file_path'],media_type=mimetypes.guess_type(r['file_path'])[0] or 'application/octet-stream')

@app.post('/api/media/{media_id}/view')
def view(media_id:str,user_id:str='demo'):
    with db() as c:
        if not c.execute("SELECT 1 FROM media WHERE id=? AND status='published'",(media_id,)).fetchone(): raise HTTPException(404,'not found')
        c.execute("UPDATE media SET view_count=view_count+1 WHERE id=?",(media_id,))
    return {'ok':True}

@app.post('/api/media/{media_id}/react')
def react(media_id:str,payload:dict[str,Any]):
    uid=str(payload.get('user_id','demo')); kind=str(payload.get('kind','like'))
    if kind not in {'like','love','fire','clap'}: raise HTTPException(400,'bad reaction')
    with db() as c:
        before=c.total_changes; c.execute("INSERT OR IGNORE INTO reactions(media_id,user_id,kind,created_at) VALUES(?,?,?,?)",(media_id,uid,kind,now())); created=c.total_changes>before
        if created: c.execute("UPDATE media SET like_count=like_count+1 WHERE id=?",(media_id,))
    return {'ok':True,'created':created}

@app.post('/api/media/{media_id}/comments')
def comment(media_id:str,payload:dict[str,Any]):
    body=str(payload.get('body','')).strip(); uid=str(payload.get('user_id','demo'))
    if not body or len(body)>1000: raise HTTPException(400,'invalid comment')
    with db() as c:
        c.execute("INSERT INTO comments(media_id,user_id,body,created_at) VALUES(?,?,?,?)",(media_id,uid,body,now())); c.execute("UPDATE media SET comment_count=comment_count+1 WHERE id=?",(media_id,))
    return {'ok':True}

class LiveCreate(BaseModel): title:str=Field(min_length=2,max_length=120); owner_id:str='demo'
@app.post('/api/live')
def create_live(payload:LiveCreate):
    lid=str(uuid.uuid4())
    with db() as c: c.execute("INSERT INTO live_rooms(id,owner_id,title,status,created_at) VALUES(?,?,?,?,?)",(lid,payload.owner_id,payload.title,'live',now()))
    return {'live_id':lid,'status':'live'}
@app.post('/api/live/{live_id}/end')
def end_live(live_id:str,payload:dict[str,Any]):
    with db() as c:
        r=c.execute("SELECT owner_id FROM live_rooms WHERE id=? AND status='live'",(live_id,)).fetchone()
        if not r: raise HTTPException(404,'live not found')
        c.execute("UPDATE live_rooms SET status='ended',ended_at=? WHERE id=?",(now(),live_id))
    return {'ended':True}


def transcode_hls(media_id:str):
    """تحويل فيديو إلى HLS عند توفر FFmpeg. لا يغيّر الملف الأصلي."""
    if not shutil.which('ffmpeg'): return
    with db() as c:
        r=c.execute("SELECT file_path,type FROM media WHERE id=?",(media_id,)).fetchone()
        if not r or r['type'] not in {'video','short'}: return
        c.execute("UPDATE media SET transcode_status='processing' WHERE id=?",(media_id,))
    outdir=MEDIA_ROOT/f"{media_id}_hls"; outdir.mkdir(exist_ok=True)
    cmd=['ffmpeg','-y','-i',r['file_path'],'-vf','scale=-2:720','-c:v','libx264','-preset','veryfast','-c:a','aac','-hls_time','4','-hls_playlist_type','vod',str(outdir/'index.m3u8')]
    result=subprocess.run(cmd,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=1800)
    with db() as c: c.execute("UPDATE media SET transcode_status=? WHERE id=?",('ready' if result.returncode==0 else 'failed',media_id))

@app.post('/api/admin/media/{media_id}/transcode')
def admin_transcode(media_id:str,bg:BackgroundTasks,x_admin_key:str=Header(default='')):
    if not ADMIN_KEY or x_admin_key!=ADMIN_KEY: raise HTTPException(403,'forbidden')
    bg.add_task(transcode_hls,media_id); return {'queued':True}

@app.get('/api/ads/next')
def next_ad(user_id:str='demo',placement:str='feed_native'):
    # نحترم حد التكرار والفاصل الزمني بدل ملء كل شاشة بالإعلانات.
    with db() as c:
        campaigns=c.execute("SELECT * FROM ad_campaigns WHERE enabled=1 AND placement=? ORDER BY (revenue+clicks*0.1+impressions*0.001) DESC,id ASC",(placement,)).fetchall()
        for camp in campaigns:
            since=now()-86400; count=c.execute("SELECT COUNT(*) FROM ad_events WHERE campaign_id=? AND user_id=? AND kind='impression' AND created_at>=?",(camp['id'],user_id,since)).fetchone()[0]
            last=c.execute("SELECT MAX(created_at) FROM ad_events WHERE campaign_id=? AND user_id=? AND kind='impression'",(camp['id'],user_id)).fetchone()[0] or 0
            if count>=camp['frequency_cap_day'] or now()-last<camp['min_interval_sec']: continue
            c.execute("INSERT INTO ad_events(campaign_id,user_id,kind,created_at) VALUES(?,?,?,?)",(camp['id'],user_id,'impression',now())); c.execute("UPDATE ad_campaigns SET impressions=impressions+1 WHERE id=?",(camp['id'],))
            return {'ad':{'id':camp['id'],'text':camp['creative_text'],'url':camp['landing_url']}}
    return {'ad':None}

@app.post('/api/ads/{campaign_id}/click')
def ad_click(campaign_id:int,payload:dict[str,Any]):
    uid=str(payload.get('user_id','demo'))
    with db() as c:
        camp=c.execute("SELECT * FROM ad_campaigns WHERE id=? AND enabled=1",(campaign_id,)).fetchone()
        if not camp: raise HTTPException(404,'campaign not found')
        revenue=float(camp['cpc']); c.execute("INSERT INTO ad_events(campaign_id,user_id,kind,revenue,created_at) VALUES(?,?,?,?,?)",(campaign_id,uid,'click',revenue,now())); c.execute("UPDATE ad_campaigns SET clicks=clicks+1,revenue=revenue+? WHERE id=?",(revenue,campaign_id))
    return {'ok':True}


@app.post('/api/admin/creator-payout')
def creator_payout(payload:dict[str,Any],x_admin_key:str=Header(default='')):
    """تسوية مكافأة منشئ موثقة من الأدمن/نظام الإيراد؛ لا تُحتسب من عداد المشاهدات المحلي وحده."""
    if not ADMIN_KEY or x_admin_key!=ADMIN_KEY: raise HTTPException(403,'forbidden')
    payout_id=str(payload.get('payout_id','')).strip(); uid=str(payload.get('user_id','')).strip(); media_id=str(payload.get('media_id','')).strip(); amount=float(payload.get('amount',0)); asset=str(payload.get('asset','CREDITS'))
    if len(payout_id)<8 or not uid or amount<=0 or amount>100000 or asset not in {'CREDITS','THF_PENDING'}: raise HTTPException(400,'invalid payout')
    with db() as c:
        if c.execute('SELECT 1 FROM creator_payouts WHERE payout_id=?',(payout_id,)).fetchone(): return {'accepted':True,'idempotent':True}
        if media_id and not c.execute('SELECT 1 FROM media WHERE id=? AND user_id=?',(media_id,uid)).fetchone(): raise HTTPException(400,'media ownership mismatch')
        c.execute('INSERT INTO creator_payouts VALUES(?,?,?,?,?,?)',(payout_id,uid,media_id,amount,asset,now()))
    reward=emit_economy_event(user_id=uid,event_type='verified_creator_revenue',amount=amount,asset=asset,metadata={'payout_id':payout_id,'media_id':media_id})
    return {'accepted':True,'idempotent':False,'economy':reward}

@app.get('/admin',response_class=HTMLResponse)
def admin(request:Request): return templates.TemplateResponse(request, 'admin.html', {})
@app.get('/api/admin/dashboard')
def admin_dashboard(x_admin_key:str=Header(default='')):
    if not ADMIN_KEY or x_admin_key!=ADMIN_KEY: raise HTTPException(403,'forbidden')
    with db() as c:
        return {'media':[dict(r) for r in c.execute("SELECT id,user_id,type,title,status,privacy,created_at,view_count,like_count,comment_count,transcode_status FROM media ORDER BY created_at DESC LIMIT 100")], 'ads':[dict(r) for r in c.execute("SELECT * FROM ad_campaigns")], 'moderation':[dict(r) for r in c.execute("SELECT * FROM moderation_queue WHERE status='open'")]}
@app.post('/api/admin/media/{media_id}/status')
def admin_status(media_id:str,payload:dict[str,Any],x_admin_key:str=Header(default='')):
    if not ADMIN_KEY or x_admin_key!=ADMIN_KEY: raise HTTPException(403,'forbidden')
    status=str(payload.get('status','hidden'))
    if status not in {'published','hidden','rejected'}: raise HTTPException(400,'bad status')
    with db() as c: c.execute("UPDATE media SET status=? WHERE id=?",(status,media_id))
    return {'ok':True}


@app.middleware("http")
async def thf_security_headers(request, call_next):
    # رؤوس أمان أساسية؛ لا نضع CSP صارمة هنا لأن الواجهة المحلية تحتوي سكربتات inline.
    response = await call_next(request)
    response.headers.setdefault("X-Content-Type-Options", "nosniff")
    response.headers.setdefault("X-Frame-Options", "SAMEORIGIN")
    response.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
    response.headers.setdefault("Permissions-Policy", "camera=(self), microphone=(self), geolocation=(self)")
    if request.url.path.startswith("/admin") or request.url.path.startswith("/api/admin"):
        response.headers["Cache-Control"] = "no-store"
    return response


# Stage16-O THF Pass federation hook
import os as _thf_os
import httpx as _thf_httpx
from fastapi import Header as _ThfHeader, HTTPException as _ThfHTTPException
_THPASS=_thf_os.getenv("THF_PASS_URL","").strip().rstrip("/")
def _thpass_ready(): return _THPASS.startswith("https://")
@app.get("/api/thf-pass/registry")
async def thf_pass_registry():
    if not _thpass_ready(): raise _ThfHTTPException(503,"thf_pass_not_configured")
    try:
        async with _thf_httpx.AsyncClient(timeout=4) as c:
            r=await c.get(_THPASS+"/api/registry")
        if r.status_code!=200: raise _ThfHTTPException(503,"thf_pass_unavailable")
        return r.json()
    except _ThfHTTPException: raise
    except Exception: raise _ThfHTTPException(503,"thf_pass_unavailable")
@app.post("/api/thf-pass/handoff/{target}")
async def thf_pass_handoff(target:str,authorization:str|None=_ThfHeader(default=None)):
    if not _thpass_ready(): raise _ThfHTTPException(503,"thf_pass_not_configured")
    if not authorization or not authorization.lower().startswith("bearer "):
        raise _ThfHTTPException(401,"thf_pass_session_required")
    try:
        async with _thf_httpx.AsyncClient(timeout=4) as c:
            r=await c.post(_THPASS+f"/api/handoff/{target}",headers={"Authorization":authorization})
        if r.status_code!=200: raise _ThfHTTPException(r.status_code,"handoff_rejected")
        return r.json()
    except _ThfHTTPException: raise
    except Exception: raise _ThfHTTPException(503,"thf_pass_unavailable")
