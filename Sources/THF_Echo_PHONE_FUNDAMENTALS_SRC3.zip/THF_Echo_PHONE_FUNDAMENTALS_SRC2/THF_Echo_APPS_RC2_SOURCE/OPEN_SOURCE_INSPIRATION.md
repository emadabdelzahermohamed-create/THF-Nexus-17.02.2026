# Open-source inspiration

إعادة كتابة أصلية، لا تنسخ كود المشاريع التالية:

- MediaCMS — Python/Django/Celery + REST، workflows وRBAC وtranscription؛ AGPL-3.0.
- PeerTube — video platform/federation/transcoding and creator patterns؛ AGPL-3.0.

أضفنا THF Stories/Shorts/Live foundation، economy outbox، native ads with frequency caps، Arabic-first admin، وفصلًا صريحًا بين المستخدم والأدمن.
