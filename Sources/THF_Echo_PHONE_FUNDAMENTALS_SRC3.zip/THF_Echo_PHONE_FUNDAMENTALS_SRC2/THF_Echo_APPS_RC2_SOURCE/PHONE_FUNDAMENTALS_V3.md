# THF Phone Fundamentals V3

- Preserves V2 onboarding, trusted HTTPS account/logout/delete call sites, RTL, accessibility preferences, package identity and icon assets.
- Requires validated Internet capability for network-required flows, rejecting captive/unvalidated connectivity.
- System Data Saver on metered networks is honored by WebView hosts in addition to the in-app Data Saver preference.
- Android notification permission is wired to a real `thf_updates` NotificationChannel; provider push delivery remains an external binding and is not claimed here.
- Private THF Publisher/Admin launcher invisibility and server-authoritative role gates remain unchanged.
- This is source-candidate evidence only until an exact-source API36 build and physical-phone acceptance succeed.
