# THF Echo — THF Pass federation

- Package: `com.topherofit.thf.echo`
- Uses bearer session issued by THF Pass.
- Shared data is reference-only: identity subject, avatar_id, locale, wallet_subject.
- No gameplay/learning/fitness database is shared between applications.
- `POST /api/thf-pass/handoff/{target}` proxies a target-bound short-lived one-time handoff request to THF Pass.
- Failure is fail-closed; no client-generated identity is accepted as federation proof.
