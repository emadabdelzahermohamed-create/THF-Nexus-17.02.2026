import os
from pathlib import Path
os.environ['DB_PATH']='/tmp/thf_media_test.db'; os.environ['MEDIA_ROOT']='/tmp/thf_media_test'
try: Path(os.environ['DB_PATH']).unlink()
except FileNotFoundError: pass
from app.main import init_db
from app.core import db

def test_schema_and_seed_ad():
    init_db()
    with db() as c:
        assert c.execute("SELECT COUNT(*) FROM ad_campaigns").fetchone()[0]>=1
        tables={r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        assert {'media','comments','reactions','live_rooms','ad_campaigns','moderation_queue','creator_payouts'}.issubset(tables)

def test_upload_type_guard_and_valid_audio():
    from fastapi.testclient import TestClient
    from app.main import app
    with TestClient(app) as c:
        bad=c.post('/upload',data={'user_id':'u','media_type':'audio','privacy':'public'},files={'file':('bad.txt',b'not-audio','text/plain')},follow_redirects=False)
        assert bad.status_code==415
        # WAV header صغير يكفي لاختبار مسار الرفع؛ الفحص العميق/anti-malware بوابة إنتاج منفصلة.
        wav=b'RIFF'+(36).to_bytes(4,'little')+b'WAVEfmt '+(16).to_bytes(4,'little')+(1).to_bytes(2,'little')+(1).to_bytes(2,'little')+(8000).to_bytes(4,'little')+(8000).to_bytes(4,'little')+(1).to_bytes(2,'little')+(8).to_bytes(2,'little')+b'data'+(0).to_bytes(4,'little')
        good=c.post('/upload',data={'user_id':'u','media_type':'audio','title':'voice','privacy':'public'},files={'file':('voice.wav',wav,'audio/wav')},follow_redirects=False)
        assert good.status_code==303
