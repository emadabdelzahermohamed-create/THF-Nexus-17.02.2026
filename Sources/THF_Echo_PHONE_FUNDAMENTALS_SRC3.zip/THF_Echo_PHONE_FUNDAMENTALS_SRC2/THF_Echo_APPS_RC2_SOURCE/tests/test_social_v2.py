import os
os.environ.setdefault('DB_PATH','/tmp/thf-link-v2-test.db')
os.environ.setdefault('MEDIA_ROOT','/tmp/thf-link-v2-media')
os.environ.setdefault('ADMIN_KEY','test-admin')
from fastapi.testclient import TestClient
from app.main import app
from app.core import ADMIN_KEY


def test_profiles_chat_privacy_safety_and_calls():
    with TestClient(app) as c:
        assert c.get('/health').json()['version']=='2.0.0'
        p=c.get('/u/coach-omar'); assert p.status_code==200
        d=c.post('/api/chats/direct',json={'user_id':'a','target_id':'b'}); assert d.status_code==200
        cid=d.json()['conversation_id']
        assert c.post(f'/api/chats/{cid}/messages',json={'user_id':'a','body':'hello'}).status_code==200
        assert c.get(f'/api/chats/{cid}/messages',params={'user_id':'a'}).json()['items'][0]['body']=='hello'
        assert c.put('/api/privacy/a',json={'data_saver':True,'allow_calls':'following','allow_messages':'following'}).status_code==200
        assert c.get('/api/playback-policy/a').json()['preferred_max_height']==360
        call=c.post('/api/calls',json={'owner_id':'a','mode':'audio'}).json(); assert call['room_id']
        assert c.post('/api/safety/report',json={'user_id':'a','target_type':'user','target_id':'b','reason':'spam'}).status_code==200
        assert c.get('/api/admin/social-safety',headers={'X-Admin-Key':'bad'}).status_code==403
        assert c.get('/api/admin/social-safety',headers={'X-Admin-Key':ADMIN_KEY}).status_code==200


def test_ads_protected_in_private_surfaces():
    with TestClient(app) as c:
        assert c.get('/api/ads/next-safe',params={'context':'private_chat'}).json()['ad'] is None
        assert c.get('/api/ads/next-safe',params={'context':'call'}).json()['ad'] is None
