#!/usr/bin/env bash
set -euo pipefail
python -m uvicorn app.main:app --host "${HOST:-0.0.0.0}" --port "${PORT:-8102}"
