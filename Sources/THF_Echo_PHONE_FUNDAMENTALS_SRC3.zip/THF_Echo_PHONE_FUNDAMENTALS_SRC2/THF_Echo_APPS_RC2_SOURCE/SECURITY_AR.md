
# أمن التشغيل

- غيّر `ADMIN_KEY` وكل أسرار `ECONOMY_SERVICE_SECRET` قبل أي نشر عام.
- لا تضع الأسرار داخل Git أو داخل تطبيق العميل.
- شغّل الخدمة خلف HTTPS reverse proxy وحدد CORS للمواقع الموثوقة فقط عند إضافة frontend خارجي.
- قاعدة SQLite مناسبة للبداية/التجربة؛ عند التوسع استخدم PostgreSQL مع نسخ احتياطي.
- اقتصاد THF لا يقبل من هذه التطبيقات أمر mint مباشر؛ التطبيقات ترسل أحداثًا موقعة فقط إلى Economy Gateway.
- راجع upload limits وfile scanning في Media قبل فتح الرفع العام على نطاق واسع.
