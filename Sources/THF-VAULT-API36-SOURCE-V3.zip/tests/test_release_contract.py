from pathlib import Path
import re
import unittest


ROOT = Path(__file__).resolve().parents[1]
GRADLE = (ROOT / "app/build.gradle").read_text(encoding="utf-8")
ACTIVITY = (ROOT / "app/src/main/java/com/topherofit/thf/vault/MainActivity.java").read_text(encoding="utf-8")
MANIFEST = (ROOT / "app/src/main/AndroidManifest.xml").read_text(encoding="utf-8")


class ReleaseContractTest(unittest.TestCase):
    def test_api36_and_release_identity(self):
        self.assertIn("compileSdk 36", GRADLE)
        self.assertIn("targetSdk 36", GRADLE)
        self.assertIn("applicationId 'com.topherofit.thf.vault'", GRADLE)

    def test_injected_backend_property_is_consumed(self):
        injected = set(re.findall(r'buildConfigField\s+"String",\s+"([A-Z0-9_]+)"', GRADLE))
        probed = set(re.findall(r'new String\[\]\{([^}]+)\}', ACTIVITY)[0].replace('"', '').replace(' ', '').split(','))
        self.assertIn("THF_BASE_URL", injected)
        self.assertIn("THF_BASE_URL", probed)

    def test_network_and_backup_fail_closed(self):
        self.assertIn('android:usesCleartextTraffic="false"', MANIFEST)
        self.assertIn('android:allowBackup="false"', MANIFEST)
        self.assertIn("startsWith(\"https://\")", ACTIVITY)
        self.assertIn("example.", ACTIVITY)

