# THF Apps RC1 native UX

Adds the previously missing launcher MainActivity plus loading, secure offline/error/retry, Data Saver and accessibility settings.
