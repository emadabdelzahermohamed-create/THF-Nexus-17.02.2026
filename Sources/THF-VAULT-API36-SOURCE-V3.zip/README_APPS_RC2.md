# THF Vault Android host — Apps RC2

Package: `com.topherofit.thf.vault`. compileSdk/targetSdk 36; minSdk 26.

Hardening delta: removed emulator/placeholder endpoint defaults; release/runtime endpoints are injected via `THF_BASE_URL` and `THF_PASS_URL`; both fail closed unless HTTPS. Added target-bound THF Pass handoff, explicit cleartext denial/network security config, RTL manifest support, and preserved Data Saver/accessibility/offline retry behavior.

No production secret/signing material is embedded. This source checkpoint is not FINAL/PLAY_READY; exact APK payload inspection, reachable backend/auth, and physical-device acceptance remain required.
