# Open-source inspiration

إعادة كتابة أصلية، لا تنسخ كود هذه المشاريع:

- Open edX — Python/Django LMS + authoring/CMS separation and scalable course delivery patterns; AGPL-3.0.
- Kolibri — Python/Django offline-first education patterns، ومناسب للاتصالات الضعيفة؛ MIT.

طبقة THF تضيف economy events، streaks، quests، spaced-repetition queue، Arabic-first UI، وفصل صريح بين learner/admin.
