import os
os.environ.setdefault('DB_PATH','/tmp/thf-quest-v2-test.db')
os.environ.setdefault('ADMIN_KEY','test-admin')
from fastapi.testclient import TestClient
from app.main import app
from app.core import ADMIN_KEY


def test_games_ambassadors_competition_and_admin():
    with TestClient(app) as c:
        assert c.get('/health').json()['version']=='2.0.0'
        assert c.get('/api/ambassadors').json()['items']
        ch=c.get('/api/games/number-dash/challenge',params={'user_id':'u'}).json(); assert ch['adaptive']
        # نختبر دورة اللعب حتى مع إجابة غير صحيحة؛ الخادم هو مصدر الحقيقة.
        r=c.post('/api/games/number-dash/submit',json={'user_id':'u','challenge_id':ch['challenge_id'],'answer':'unlikely'}); assert r.status_code==200 and 'correct' in r.json()
        p=c.get('/api/games/number-dash/progress/u').json(); assert p['total']==1
        assert c.get('/api/admin/quest-expansion',headers={'X-Admin-Key':'bad'}).status_code==403
        assert c.get('/api/admin/quest-expansion',headers={'X-Admin-Key':ADMIN_KEY}).status_code==200


def test_ads_protected_during_game_round():
    with TestClient(app) as c:
        assert c.get('/api/ads/next-quest',params={'context':'game_round'}).json()['ad'] is None

def test_game_page_uses_playable_canvas_runtime():
    with TestClient(app) as c:
        r=c.get('/game/number-dash',params={'user':'u'})
        assert r.status_code==200
        assert 'gameCanvas' in r.text and '/static/games.js' in r.text
