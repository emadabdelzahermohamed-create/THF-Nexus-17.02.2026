import os
from pathlib import Path
os.environ['DB_PATH']='/tmp/thf_learn_test.db'
try:Path(os.environ['DB_PATH']).unlink()
except FileNotFoundError:pass
from app.main import init_db,update_review
from app.core import db

def test_seed_content():
    init_db()
    with db() as c:
        assert c.execute('SELECT COUNT(*) FROM courses').fetchone()[0]>=4
        assert c.execute('SELECT COUNT(*) FROM lessons').fetchone()[0]>=10
        assert c.execute('SELECT COUNT(*) FROM questions').fetchone()[0]>=10

def test_spaced_repetition_progression():
    ease,interval,reps=update_review(ease=2.5,interval=1,reps=0,quality=5)
    assert interval==1 and reps==1
    ease,interval,reps=update_review(ease=ease,interval=interval,reps=reps,quality=5)
    assert interval==6 and reps==2

def test_failed_review_resets_interval():
    ease,interval,reps=update_review(ease=2.5,interval=10,reps=3,quality=2)
    assert interval==1 and reps==0
