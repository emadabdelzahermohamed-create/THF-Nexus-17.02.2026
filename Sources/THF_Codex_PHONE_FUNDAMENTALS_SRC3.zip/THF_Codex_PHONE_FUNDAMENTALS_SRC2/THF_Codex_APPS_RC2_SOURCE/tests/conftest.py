"""عزل قاعدة بيانات الاختبارات حتى تكون الاختبارات قابلة للتكرار ولا تعتمد على تشغيل سابق."""
import os
from pathlib import Path

TEST_DB = "/tmp/thf_quest_v2_suite.db"
os.environ["DB_PATH"] = TEST_DB
os.environ.setdefault("ADMIN_KEY", "test-admin")
try:
    Path(TEST_DB).unlink()
except FileNotFoundError:
    pass
