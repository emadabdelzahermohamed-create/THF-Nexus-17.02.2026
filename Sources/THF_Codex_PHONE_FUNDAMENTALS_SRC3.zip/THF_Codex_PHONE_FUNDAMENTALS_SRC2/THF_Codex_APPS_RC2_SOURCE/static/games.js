/* THF Codex — محرك ألعاب تعليمية خفيف بدون مكتبات خارجية.
   الخادم يظل مصدر الحقيقة للإجابة والتقدم والـrating والمكافآت. */
(() => {
  'use strict';
  const root = document.getElementById('gameRoot');
  if (!root) return;
  const slug = root.dataset.slug;
  const user = root.dataset.user;
  const canvas = document.getElementById('gameCanvas');
  const ctx = canvas.getContext('2d');
  const promptEl = document.getElementById('prompt');
  const difficultyEl = document.getElementById('difficulty');
  const choicesEl = document.getElementById('choices');
  const feedbackEl = document.getElementById('feedback');
  const ratingEl = document.getElementById('rating');
  const timerEl = document.getElementById('timer');
  const livesEl = document.getElementById('livesHud');
  const roundEl = document.getElementById('roundHud');
  const controls = document.getElementById('dashControls');

  let challenge = null;
  let targets = [];
  let running = false;
  let round = 0;
  let lives = 3;
  let lane = 1;
  let startedAt = 0;
  let raf = 0;
  let rotation = 0;
  const roundLimit = 12_000;

  function resizeCanvas() {
    const rect = canvas.getBoundingClientRect();
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = Math.max(480, Math.floor(rect.width * dpr));
    canvas.height = Math.max(300, Math.floor(rect.height * dpr));
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }

  function dims() {
    const rect = canvas.getBoundingClientRect();
    return {w: rect.width, h: rect.height};
  }

  function rounded(x,y,w,h,r=14) {
    ctx.beginPath(); ctx.roundRect(x,y,w,h,r); ctx.fill();
  }

  function textCenter(text,x,y,size=20) {
    ctx.font = `800 ${size}px system-ui`; ctx.textAlign='center'; ctx.textBaseline='middle'; ctx.fillText(text,x,y);
  }

  function drawBackdrop(w,h) {
    const g=ctx.createLinearGradient(0,0,0,h); g.addColorStop(0,'#171433'); g.addColorStop(1,'#070911');
    ctx.fillStyle=g;ctx.fillRect(0,0,w,h);
    for(let i=0;i<36;i++){
      const x=(i*97+rotation*17)%w, y=(i*47)%Math.max(1,h*.7);
      ctx.globalAlpha=.25+.25*((i%4)/3);ctx.fillStyle='#fff';ctx.fillRect(x,y,2,2);
    }
    ctx.globalAlpha=1;
  }

  function drawNumberDash(w,h,elapsed) {
    controls.hidden=false;
    const lanes=Math.max(2,challenge?.choices.length||4); const roadW=Math.min(w*.86,720); const left=(w-roadW)/2;
    ctx.fillStyle='#141824';rounded(left,0,roadW,h,24);
    ctx.strokeStyle='#545d78';ctx.lineWidth=2;ctx.setLineDash([18,20]);
    for(let i=1;i<lanes;i++){const x=left+roadW*i/lanes;ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,h);ctx.stroke();}
    ctx.setLineDash([]);
    const gateY=50+(elapsed/roundLimit)*(h*.58);
    targets=[];
    challenge?.choices.forEach((choice,i)=>{
      const lw=roadW/lanes;const x=left+i*lw+8;const width=lw-16;const y=gateY;
      ctx.fillStyle=i===lane?'#f4c85a':'#292f43';rounded(x,y,width,62,14);
      ctx.fillStyle=i===lane?'#191306':'#fff';textCenter(choice,x+width/2,y+31,Math.max(15,Math.min(23,width/4)));
      targets.push({x,y,w:width,h:62,answer:choice,index:i});
    });
    const lw=roadW/lanes; const px=left+lane*lw+lw/2;const py=h-74;
    ctx.fillStyle='#8b5cf6';ctx.beginPath();ctx.arc(px,py-24,13,0,Math.PI*2);ctx.fill();
    ctx.strokeStyle='#c4b5fd';ctx.lineWidth=6;ctx.lineCap='round';
    ctx.beginPath();ctx.moveTo(px,py-10);ctx.lineTo(px,py+24);ctx.moveTo(px,py);ctx.lineTo(px-15,py+12);ctx.moveTo(px,py);ctx.lineTo(px+15,py+12);ctx.moveTo(px,py+24);ctx.lineTo(px-12,py+48);ctx.moveTo(px,py+24);ctx.lineTo(px+12,py+48);ctx.stroke();
  }

  function drawWordForge(w,h,elapsed) {
    controls.hidden=true; targets=[];
    ctx.fillStyle='#2a1510';rounded(w*.12,h*.16,w*.76,h*.67,26);
    ctx.fillStyle='#ff8a3d33';ctx.beginPath();ctx.arc(w*.5,h*.78,Math.min(w,h)*.17,0,Math.PI*2);ctx.fill();
    ctx.fillStyle='#ffb34d';textCenter('FORGE',w*.5,h*.78,22);
    const choices=challenge?.choices||[];
    choices.forEach((choice,i)=>{
      const cols=2;const col=i%cols,row=Math.floor(i/cols);const bw=Math.min(240,w*.34),bh=72;
      const baseX=w*.28+col*w*.44-bw/2;const baseY=h*.24+row*112;
      const float=Math.sin((elapsed/500)+i*1.7)*10;
      ctx.shadowColor='#f97316';ctx.shadowBlur=14;ctx.fillStyle='#332c36';rounded(baseX,baseY+float,bw,bh,18);ctx.shadowBlur=0;
      ctx.fillStyle='#f8fafc';textCenter(choice,baseX+bw/2,baseY+float+bh/2,18);
      targets.push({x:baseX,y:baseY+float,w:bw,h:bh,answer:choice,index:i});
    });
  }

  function drawScienceOrbit(w,h,elapsed) {
    controls.hidden=true;targets=[];const cx=w/2,cy=h/2;
    ctx.strokeStyle='#615c85';ctx.lineWidth=2;
    [90,150,210].forEach(r=>{ctx.beginPath();ctx.ellipse(cx,cy,r,Math.max(50,r*.45),0,0,Math.PI*2);ctx.stroke();});
    ctx.fillStyle='#f4c85a';ctx.shadowColor='#f4c85a';ctx.shadowBlur=28;ctx.beginPath();ctx.arc(cx,cy,42,0,Math.PI*2);ctx.fill();ctx.shadowBlur=0;
    const choices=challenge?.choices||[];
    choices.forEach((choice,i)=>{
      const angle=rotation*.7+i*(Math.PI*2/choices.length);const rx=165+(i%2)*38,ry=82+(i%2)*18;
      const x=cx+Math.cos(angle)*rx,y=cy+Math.sin(angle)*ry;
      ctx.fillStyle=['#60a5fa','#a78bfa','#34d399','#fb7185'][i%4];ctx.beginPath();ctx.arc(x,y,34,0,Math.PI*2);ctx.fill();
      ctx.fillStyle='#071018';textCenter(String(i+1),x,y,17);ctx.fillStyle='#fff';textCenter(choice,x,y+50,14);
      targets.push({x:x-38,y:y-38,w:76,h:76,answer:choice,index:i});
    });
  }

  function frame(ts) {
    if(!startedAt) startedAt=ts;
    const elapsed=ts-startedAt;rotation+=.012;
    const {w,h}=dims();ctx.clearRect(0,0,w,h);drawBackdrop(w,h);
    if(slug==='number-dash') drawNumberDash(w,h,elapsed);
    else if(slug==='word-forge') drawWordForge(w,h,elapsed);
    else drawScienceOrbit(w,h,elapsed);
    const remain=Math.max(0,(roundLimit-elapsed)/1000);timerEl.textContent=remain.toFixed(1)+'s';
    if(running && elapsed>=roundLimit){ running=false; submit('__timeout__'); return; }
    raf=requestAnimationFrame(frame);
  }

  function fallbackChoices() {
    choicesEl.innerHTML='';
    (challenge?.choices||[]).forEach((value,i)=>{
      const b=document.createElement('button');b.className='choice';b.type='button';b.textContent=`${i+1}. ${value}`;b.onclick=()=>submit(value);choicesEl.appendChild(b);
    });
  }

  async function next() {
    running=false;cancelAnimationFrame(raf);feedbackEl.textContent='';feedbackEl.className='feedback';
    const r=await fetch(`/api/games/${encodeURIComponent(slug)}/challenge?user_id=${encodeURIComponent(user)}`);
    if(!r.ok){feedbackEl.textContent='تعذر تحميل الجولة';feedbackEl.className='feedback bad';return;}
    challenge=await r.json();round+=1;roundEl.textContent='الجولة '+round;promptEl.textContent=challenge.prompt;difficultyEl.textContent='صعوبة '+challenge.difficulty;
    fallbackChoices();lane=Math.min(lane,Math.max(0,challenge.choices.length-1));startedAt=0;running=true;raf=requestAnimationFrame(frame);
  }

  async function submit(answer) {
    if(!challenge || (feedbackEl.dataset.locked==='1')) return;
    feedbackEl.dataset.locked='1';running=false;cancelAnimationFrame(raf);[...choicesEl.children].forEach(b=>b.disabled=true);
    const r=await fetch(`/api/games/${encodeURIComponent(slug)}/submit`,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({user_id:user,challenge_id:challenge.challenge_id,answer})});
    const j=await r.json();
    if(!r.ok){feedbackEl.textContent=j.detail||'تعذر تسجيل الجولة';feedbackEl.className='feedback bad';feedbackEl.dataset.locked='0';return;}
    if(!j.correct){lives=Math.max(0,lives-1);} else if(round%5===0 && lives<3){lives+=1;}
    livesEl.textContent='♥'.repeat(lives)+'♡'.repeat(3-lives);ratingEl.textContent='Rating '+Math.round(j.rating);
    feedbackEl.textContent=j.correct?'✓ ضربة صحيحة — تقدمك محفوظ على الخادم':(answer==='__timeout__'?'⌛ انتهى الوقت':'✕ الصحيح: '+j.correct_answer);
    feedbackEl.className='feedback '+(j.correct?'ok':'bad');
    if(lives===0){feedbackEl.textContent+=' — استراحة قصيرة ثم نعيد المحاولة.';lives=3;round=0;}
    setTimeout(()=>{feedbackEl.dataset.locked='0';next();},1050);
  }

  function hit(x,y){
    for(const t of targets){if(x>=t.x&&x<=t.x+t.w&&y>=t.y&&y<=t.y+t.h){if(slug==='number-dash'){lane=t.index;} else submit(t.answer);return;}}
  }
  canvas.addEventListener('pointerdown',e=>{const r=canvas.getBoundingClientRect();hit(e.clientX-r.left,e.clientY-r.top);});
  document.addEventListener('keydown',e=>{
    if(slug==='number-dash'){
      if(e.key==='ArrowLeft'){lane=Math.max(0,lane-1);e.preventDefault();}
      if(e.key==='ArrowRight'){lane=Math.min((challenge?.choices.length||1)-1,lane+1);e.preventDefault();}
      if((e.key===' '||e.key==='Enter')&&challenge){submit(challenge.choices[lane]);e.preventDefault();}
    }
    const n=Number(e.key);if(n>=1&&n<=(challenge?.choices.length||0)){submit(challenge.choices[n-1]);}
  });
  controls.addEventListener('click',e=>{const m=e.target?.dataset?.move;if(!m)return;if(m==='left')lane=Math.max(0,lane-1);if(m==='right')lane=Math.min((challenge?.choices.length||1)-1,lane+1);if(m==='select'&&challenge)submit(challenge.choices[lane]);});
  window.addEventListener('resize',resizeCanvas);resizeCanvas();next();
})();
