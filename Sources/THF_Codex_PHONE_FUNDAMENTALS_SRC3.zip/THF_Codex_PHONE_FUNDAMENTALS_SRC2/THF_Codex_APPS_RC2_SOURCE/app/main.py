from __future__ import annotations
import json, math
from pathlib import Path
from typing import Any
from contextlib import asynccontextmanager
from fastapi import FastAPI, Header, HTTPException, Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from .core import ADMIN_KEY, db, emit_economy_event, now
from .seed import COURSES
from .expansion import router as expansion_router, init_expansion_db

BASE=Path(__file__).resolve().parent.parent
@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    init_expansion_db()
    yield

app=FastAPI(title='THF Codex',version='2.1.0-stage16o',lifespan=lifespan); app.mount('/static',StaticFiles(directory=BASE/'static'),name='static')
app.include_router(expansion_router); templates=Jinja2Templates(directory=BASE/'templates')

def init_db():
    with db() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS courses(id INTEGER PRIMARY KEY AUTOINCREMENT,slug TEXT UNIQUE,title TEXT,category TEXT,level TEXT,description TEXT,active INTEGER DEFAULT 1);
        CREATE TABLE IF NOT EXISTS lessons(id INTEGER PRIMARY KEY AUTOINCREMENT,course_id INTEGER,title TEXT,content TEXT,position INTEGER,FOREIGN KEY(course_id) REFERENCES courses(id));
        CREATE TABLE IF NOT EXISTS questions(id INTEGER PRIMARY KEY AUTOINCREMENT,lesson_id INTEGER,prompt TEXT,answer TEXT,choices_json TEXT,FOREIGN KEY(lesson_id) REFERENCES lessons(id));
        CREATE TABLE IF NOT EXISTS enrollments(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id TEXT,course_id INTEGER,started_at INTEGER,UNIQUE(user_id,course_id));
        CREATE TABLE IF NOT EXISTS lesson_progress(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id TEXT,lesson_id INTEGER,completed_at INTEGER,mastery REAL DEFAULT 0,UNIQUE(user_id,lesson_id));
        CREATE TABLE IF NOT EXISTS attempts(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id TEXT,question_id INTEGER,answer TEXT,correct INTEGER,created_at INTEGER);
        CREATE TABLE IF NOT EXISTS review_queue(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id TEXT,question_id INTEGER,ease REAL DEFAULT 2.5,interval_days INTEGER DEFAULT 1,repetitions INTEGER DEFAULT 0,due_at INTEGER,UNIQUE(user_id,question_id));
        CREATE TABLE IF NOT EXISTS streaks(user_id TEXT PRIMARY KEY,last_day TEXT,current_streak INTEGER DEFAULT 0,longest_streak INTEGER DEFAULT 0);
        CREATE TABLE IF NOT EXISTS quests(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT,target_lessons INTEGER,reward_xp INTEGER,active INTEGER DEFAULT 1);
        CREATE TABLE IF NOT EXISTS economy_outbox(event_id TEXT PRIMARY KEY,payload_json TEXT,status TEXT,created_at INTEGER);
        """)
        if c.execute('SELECT COUNT(*) FROM courses').fetchone()[0]==0:
            for course in COURSES:
                cur=c.execute('INSERT INTO courses(slug,title,category,level,description) VALUES(?,?,?,?,?)',(course['slug'],course['title'],course['category'],course['level'],course['description'])); cid=cur.lastrowid
                for pos,(title,content,questions) in enumerate(course['lessons'],1):
                    lcur=c.execute('INSERT INTO lessons(course_id,title,content,position) VALUES(?,?,?,?)',(cid,title,content,pos)); lid=lcur.lastrowid
                    for prompt,answer,choices in questions:
                        c.execute('INSERT INTO questions(lesson_id,prompt,answer,choices_json) VALUES(?,?,?,?)',(lid,prompt,answer,json.dumps(choices.split('|'),ensure_ascii=False)))
        if c.execute('SELECT COUNT(*) FROM quests').fetchone()[0]==0:
            c.execute('INSERT INTO quests(title,target_lessons,reward_xp) VALUES(?,?,?)',('أكمل 3 دروس اليوم',3,20))
            c.execute('INSERT INTO quests(title,target_lessons,reward_xp) VALUES(?,?,?)',('أكمل 7 دروس هذا الأسبوع',7,50))
@app.get('/health')
def health(): return {'ok':True,'service':'THF Codex','version':'2.0.0','economy_service':'learn'}

@app.get('/',response_class=HTMLResponse)
def home(request:Request,user:str='demo'):
    with db() as c:
        courses=c.execute('SELECT * FROM courses WHERE active=1 ORDER BY title').fetchall(); progress=c.execute('SELECT COUNT(*) FROM lesson_progress WHERE user_id=?',(user,)).fetchone()[0]
        streak=c.execute('SELECT * FROM streaks WHERE user_id=?',(user,)).fetchone(); reviews=c.execute('SELECT COUNT(*) FROM review_queue WHERE user_id=? AND due_at<=?',(user,now())).fetchone()[0]
    return templates.TemplateResponse(request, 'home.html', {'courses':courses,'progress':progress,'streak':streak,'reviews':reviews,'user':user})

@app.get('/course/{slug}',response_class=HTMLResponse)
def course_page(request:Request,slug:str,user:str='demo'):
    with db() as c:
        course=c.execute('SELECT * FROM courses WHERE slug=? AND active=1',(slug,)).fetchone()
        if not course: raise HTTPException(404,'course not found')
        lessons=c.execute('SELECT l.*,CASE WHEN p.id IS NULL THEN 0 ELSE 1 END completed FROM lessons l LEFT JOIN lesson_progress p ON p.lesson_id=l.id AND p.user_id=? WHERE l.course_id=? ORDER BY position',(user,course['id'])).fetchall()
    return templates.TemplateResponse(request, 'course.html', {'course':course,'lessons':lessons,'user':user})

@app.get('/lesson/{lesson_id}',response_class=HTMLResponse)
def lesson_page(request:Request,lesson_id:int,user:str='demo'):
    with db() as c:
        lesson=c.execute('SELECT l.*,c.title course_title,c.slug course_slug FROM lessons l JOIN courses c ON c.id=l.course_id WHERE l.id=?',(lesson_id,)).fetchone()
        if not lesson: raise HTTPException(404,'lesson not found')
        qs=[dict(r) for r in c.execute('SELECT id,prompt,choices_json FROM questions WHERE lesson_id=?',(lesson_id,))]
        for q in qs:q['choices']=json.loads(q['choices_json'])
    return templates.TemplateResponse(request, 'lesson.html', {'lesson':lesson,'questions':qs,'user':user})

def _update_streak(c,user_id:str):
    from datetime import date,timedelta
    today=date.today(); t=today.isoformat(); row=c.execute('SELECT * FROM streaks WHERE user_id=?',(user_id,)).fetchone()
    if not row: c.execute('INSERT INTO streaks(user_id,last_day,current_streak,longest_streak) VALUES(?,?,1,1)',(user_id,t)); return 1
    if row['last_day']==t:return row['current_streak']
    yesterday=(today-timedelta(days=1)).isoformat(); streak=row['current_streak']+1 if row['last_day']==yesterday else 1; longest=max(row['longest_streak'],streak)
    c.execute('UPDATE streaks SET last_day=?,current_streak=?,longest_streak=? WHERE user_id=?',(t,streak,longest,user_id)); return streak

@app.post('/api/lesson/{lesson_id}/complete')
def complete_lesson(lesson_id:int,payload:dict[str,Any]):
    uid=str(payload.get('user_id','demo'))
    with db() as c:
        if not c.execute('SELECT 1 FROM lessons WHERE id=?',(lesson_id,)).fetchone():raise HTTPException(404,'lesson not found')
        before=c.total_changes; c.execute('INSERT OR IGNORE INTO lesson_progress(user_id,lesson_id,completed_at,mastery) VALUES(?,?,?,?)',(uid,lesson_id,now(),0.5)); created=c.total_changes>before
        streak=_update_streak(c,uid)
    reward=emit_economy_event(user_id=uid,event_type='lesson_completed',amount=5,asset='XP',metadata={'lesson_id':lesson_id}) if created else None
    return {'completed':True,'first_time':created,'streak':streak,'reward':reward}


def update_review(*,ease:float,interval:int,reps:int,quality:int)->tuple[float,int,int]:
    """مراجعة متباعدة مبسطة على نمط SM-2 مع حدود تمنع القيم غير المعقولة."""
    quality=max(0,min(5,quality))
    if quality<3:return max(1.3,ease-0.2),1,0
    reps+=1
    if reps==1: interval=1
    elif reps==2: interval=6
    else: interval=max(1,round(interval*ease))
    ease=max(1.3,ease+(0.1-(5-quality)*(0.08+(5-quality)*0.02)))
    return round(ease,3),interval,reps

@app.post('/api/questions/{question_id}/answer')
def answer(question_id:int,payload:dict[str,Any]):
    uid=str(payload.get('user_id','demo')); answer=str(payload.get('answer','')).strip()
    with db() as c:
        q=c.execute('SELECT * FROM questions WHERE id=?',(question_id,)).fetchone()
        if not q:raise HTTPException(404,'question not found')
        correct=int(answer.casefold()==str(q['answer']).casefold()); c.execute('INSERT INTO attempts(user_id,question_id,answer,correct,created_at) VALUES(?,?,?,?,?)',(uid,question_id,answer,correct,now()))
        rq=c.execute('SELECT * FROM review_queue WHERE user_id=? AND question_id=?',(uid,question_id)).fetchone(); ease=float(rq['ease']) if rq else 2.5; interval=int(rq['interval_days']) if rq else 1; reps=int(rq['repetitions']) if rq else 0
        ease,interval,reps=update_review(ease=ease,interval=interval,reps=reps,quality=5 if correct else 2); due=now()+interval*86400
        c.execute('INSERT INTO review_queue(user_id,question_id,ease,interval_days,repetitions,due_at) VALUES(?,?,?,?,?,?) ON CONFLICT(user_id,question_id) DO UPDATE SET ease=excluded.ease,interval_days=excluded.interval_days,repetitions=excluded.repetitions,due_at=excluded.due_at',(uid,question_id,ease,interval,reps,due))
    return {'correct':bool(correct),'correct_answer':q['answer'] if not correct else None,'next_review_days':interval}

@app.get('/api/reviews/{user_id}')
def due_reviews(user_id:str):
    with db() as c:
        rows=c.execute('SELECT rq.question_id,q.prompt,q.choices_json FROM review_queue rq JOIN questions q ON q.id=rq.question_id WHERE rq.user_id=? AND rq.due_at<=? ORDER BY rq.due_at LIMIT 30',(user_id,now())).fetchall()
    return {'items':[{'question_id':r['question_id'],'prompt':r['prompt'],'choices':json.loads(r['choices_json'])} for r in rows]}

@app.get('/api/leaderboard')
def leaderboard():
    with db() as c:
        rows=c.execute('SELECT user_id,COUNT(*) completed FROM lesson_progress GROUP BY user_id ORDER BY completed DESC,user_id LIMIT 50').fetchall()
    return {'leaderboard':[dict(r) for r in rows]}

@app.get('/admin',response_class=HTMLResponse)
def admin(request:Request):return templates.TemplateResponse(request, 'admin.html', {})
@app.get('/api/admin/catalog')
def admin_catalog(x_admin_key:str=Header(default='')):
    if not ADMIN_KEY or x_admin_key!=ADMIN_KEY:raise HTTPException(403,'forbidden')
    with db() as c:return {'courses':[dict(r) for r in c.execute('SELECT * FROM courses')],'lessons':[dict(r) for r in c.execute('SELECT id,course_id,title,position FROM lessons ORDER BY course_id,position')],'questions_count':c.execute('SELECT COUNT(*) FROM questions').fetchone()[0],'quests':[dict(r) for r in c.execute('SELECT * FROM quests')]}
@app.post('/api/admin/courses')
def add_course(payload:dict[str,Any],x_admin_key:str=Header(default='')):
    if not ADMIN_KEY or x_admin_key!=ADMIN_KEY:raise HTTPException(403,'forbidden')
    with db() as c:c.execute('INSERT INTO courses(slug,title,category,level,description) VALUES(?,?,?,?,?)',(payload['slug'],payload['title'],payload.get('category','general'),payload.get('level','beginner'),payload.get('description','')))
    return {'created':True}


@app.middleware("http")
async def thf_security_headers(request, call_next):
    # رؤوس أمان أساسية؛ لا نضع CSP صارمة هنا لأن الواجهة المحلية تحتوي سكربتات inline.
    response = await call_next(request)
    response.headers.setdefault("X-Content-Type-Options", "nosniff")
    response.headers.setdefault("X-Frame-Options", "SAMEORIGIN")
    response.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
    response.headers.setdefault("Permissions-Policy", "camera=(self), microphone=(self), geolocation=(self)")
    if request.url.path.startswith("/admin") or request.url.path.startswith("/api/admin"):
        response.headers["Cache-Control"] = "no-store"
    return response


# Stage16-O THF Pass federation hook
import os as _thf_os
import httpx as _thf_httpx
from fastapi import Header as _ThfHeader, HTTPException as _ThfHTTPException
_THPASS=_thf_os.getenv("THF_PASS_URL","").strip().rstrip("/")
def _thpass_ready(): return _THPASS.startswith("https://")
@app.get("/api/thf-pass/registry")
async def thf_pass_registry():
    if not _thpass_ready(): raise _ThfHTTPException(503,"thf_pass_not_configured")
    try:
        async with _thf_httpx.AsyncClient(timeout=4) as c:
            r=await c.get(_THPASS+"/api/registry")
        if r.status_code!=200: raise _ThfHTTPException(503,"thf_pass_unavailable")
        return r.json()
    except _ThfHTTPException: raise
    except Exception: raise _ThfHTTPException(503,"thf_pass_unavailable")
@app.post("/api/thf-pass/handoff/{target}")
async def thf_pass_handoff(target:str,authorization:str|None=_ThfHeader(default=None)):
    if not _thpass_ready(): raise _ThfHTTPException(503,"thf_pass_not_configured")
    if not authorization or not authorization.lower().startswith("bearer "):
        raise _ThfHTTPException(401,"thf_pass_session_required")
    try:
        async with _thf_httpx.AsyncClient(timeout=4) as c:
            r=await c.post(_THPASS+f"/api/handoff/{target}",headers={"Authorization":authorization})
        if r.status_code!=200: raise _ThfHTTPException(r.status_code,"handoff_rejected")
        return r.json()
    except _ThfHTTPException: raise
    except Exception: raise _ThfHTTPException(503,"thf_pass_unavailable")
