from __future__ import annotations

"""توسعات THF Codex: سفراء، مسابقات، تصويت اقتصادي، وألعاب تعليمية تكيفية حقيقية."""

import hashlib
import hmac
import json
import os
import random
import uuid
from typing import Any

import httpx
from fastapi import APIRouter, Header, HTTPException, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates

from .core import ADMIN_KEY, ECONOMY_SERVICE, ECONOMY_SERVICE_SECRET, ECONOMY_URL, db, emit_economy_event, now

router = APIRouter()
BASE = os.path.dirname(os.path.dirname(__file__))
templates = Jinja2Templates(directory=os.path.join(BASE, "templates"))
MEDIA_BASE_URL = os.getenv("MEDIA_BASE_URL", "").strip().rstrip("/")
STORE_BASE_URL = os.getenv("STORE_BASE_URL", "").strip().rstrip("/")

VOCAB = [("apple","تفاحة"),("book","كتاب"),("water","ماء"),("friend","صديق"),("school","مدرسة"),("strength","قوة"),("future","مستقبل"),("learn","يتعلم")]
SCIENCE = [("Earth","planet"),("Sun","star"),("Moon","satellite"),("Mars","planet"),("Jupiter","planet"),("Sirius","star")]


def init_expansion_db() -> None:
    with db() as c:
        c.executescript(
            """
            CREATE TABLE IF NOT EXISTS ambassadors(
              id INTEGER PRIMARY KEY AUTOINCREMENT, handle TEXT UNIQUE, display_name TEXT, focus TEXT,
              bio TEXT, media_url TEXT, verified INTEGER DEFAULT 0, active INTEGER DEFAULT 1
            );
            CREATE TABLE IF NOT EXISTS learning_competitions(
              id INTEGER PRIMARY KEY AUTOINCREMENT, slug TEXT UNIQUE, title TEXT, game_slug TEXT,
              start_at INTEGER, end_at INTEGER, reward_xp REAL DEFAULT 0, active INTEGER DEFAULT 1
            );
            CREATE TABLE IF NOT EXISTS learning_competition_entries(
              competition_id INTEGER, user_id TEXT, score REAL DEFAULT 0, verified INTEGER DEFAULT 1,
              updated_at INTEGER, PRIMARY KEY(competition_id,user_id)
            );
            CREATE TABLE IF NOT EXISTS competition_proposals(
              id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, description TEXT, created_by TEXT,
              status TEXT DEFAULT 'voting', min_thf_balance REAL DEFAULT 1, created_at INTEGER
            );
            CREATE TABLE IF NOT EXISTS competition_votes(
              proposal_id INTEGER, user_id TEXT, weight REAL, created_at INTEGER,
              PRIMARY KEY(proposal_id,user_id)
            );
            CREATE TABLE IF NOT EXISTS games(
              slug TEXT PRIMARY KEY, title TEXT, category TEXT, description TEXT, launch_url TEXT,
              kind TEXT DEFAULT 'local', active INTEGER DEFAULT 1
            );
            CREATE TABLE IF NOT EXISTS game_challenges(
              id TEXT PRIMARY KEY, user_id TEXT, game_slug TEXT, prompt TEXT, choices_json TEXT,
              answer TEXT, difficulty INTEGER, created_at INTEGER, answered_at INTEGER
            );
            CREATE TABLE IF NOT EXISTS game_progress(
              user_id TEXT, game_slug TEXT, rating REAL DEFAULT 1000, correct INTEGER DEFAULT 0,
              total INTEGER DEFAULT 0, streak INTEGER DEFAULT 0, best_streak INTEGER DEFAULT 0,
              PRIMARY KEY(user_id,game_slug)
            );
            CREATE TABLE IF NOT EXISTS quest_ad_campaigns(
              id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, placement TEXT, creative_text TEXT,
              landing_url TEXT, enabled INTEGER DEFAULT 1, frequency_cap_day INTEGER DEFAULT 2,
              min_interval_sec INTEGER DEFAULT 1200, impressions INTEGER DEFAULT 0
            );
            CREATE TABLE IF NOT EXISTS quest_ad_events(
              id INTEGER PRIMARY KEY AUTOINCREMENT, campaign_id INTEGER, user_id TEXT, kind TEXT, created_at INTEGER
            );
            CREATE TABLE IF NOT EXISTS quest_privacy(
              user_id TEXT PRIMARY KEY, data_saver INTEGER DEFAULT 0, public_progress INTEGER DEFAULT 0,
              show_leaderboard_name INTEGER DEFAULT 1, updated_at INTEGER
            );
            """
        )
        if c.execute("SELECT COUNT(*) FROM ambassadors").fetchone()[0] == 0:
            c.executemany("INSERT INTO ambassadors(handle,display_name,focus,bio,media_url,verified) VALUES(?,?,?,?,?,?)", [
                ("ambassador-lina","لينا — سفيرة تعلم","languages","تشجع تحديات اللغات والتعلم اليومي.",f"{MEDIA_BASE_URL}/u/ambassador-lina",0),
                ("ambassador-yousef","يوسف — سفير STEM","science","يربط المسابقات العلمية بالألعاب والمشاريع.",f"{MEDIA_BASE_URL}/u/ambassador-yousef",0),
            ])
        if c.execute("SELECT COUNT(*) FROM games").fetchone()[0] == 0:
            c.executemany("INSERT INTO games(slug,title,category,description,launch_url,kind) VALUES(?,?,?,?,?,?)", [
                ("number-dash","Number Dash","math","لعبة حساب تكيفية بزمن وحركة تتغير صعوبتها حسب الأداء.","/game/number-dash","local"),
                ("word-forge","Word Forge","languages","لعبة مفردات عربية/إنجليزية تكيفية.","/game/word-forge","local"),
                ("science-orbit","Science Orbit","science","لعبة تصنيف علمي متحركة.","/game/science-orbit","local"),
            ])
        if c.execute("SELECT COUNT(*) FROM learning_competitions").fetchone()[0] == 0:
            t=now(); c.execute("INSERT INTO learning_competitions(slug,title,game_slug,start_at,end_at,reward_xp) VALUES(?,?,?,?,?,?)",("number-dash-week","Number Dash Weekly","number-dash",t-3600,t+7*86400,100))
        if c.execute("SELECT COUNT(*) FROM competition_proposals").fetchone()[0] == 0:
            c.execute("INSERT INTO competition_proposals(title,description,created_by,status,min_thf_balance,created_at) VALUES(?,?,?,?,?,?)",("تحدي علوم الفضاء","اقتراح مسابقة أسبوعية داخل Science Orbit.","system","voting",1,now()))
        if c.execute("SELECT COUNT(*) FROM quest_ad_campaigns").fetchone()[0] == 0:
            c.execute("INSERT INTO quest_ad_campaigns(name,placement,creative_text,landing_url) VALUES(?,?,?,?)",("Learning Partner","home_native","محتوى شريك تعليمي — بعيد عن الاختبار واللعبة",STORE_BASE_URL))


def _economy_balance(user_id: str) -> dict[str, float]:
    if not ECONOMY_URL:
        raise HTTPException(503, "economy unavailable")
    try:
        r=httpx.get(f"{ECONOMY_URL}/balances/{user_id}",timeout=3.0); r.raise_for_status(); return {k:float(v) for k,v in r.json().get("balances",{}).items()}
    except HTTPException: raise
    except Exception as exc: raise HTTPException(503, f"economy unavailable: {type(exc).__name__}") from exc


@router.get("/community", response_class=HTMLResponse)
def community(request: Request, user: str="demo"):
    with db() as c:
        ambassadors=c.execute("SELECT * FROM ambassadors WHERE active=1 ORDER BY verified DESC,display_name").fetchall()
        comps=c.execute("SELECT * FROM learning_competitions WHERE active=1 ORDER BY end_at").fetchall()
        proposals=c.execute("SELECT p.*,COALESCE(SUM(v.weight),0) votes FROM competition_proposals p LEFT JOIN competition_votes v ON v.proposal_id=p.id GROUP BY p.id ORDER BY p.created_at DESC").fetchall()
    return templates.TemplateResponse(request, "community.html", {"user":user,"ambassadors":ambassadors,"competitions":comps,"proposals":proposals,"media_url":MEDIA_BASE_URL})


@router.get("/games", response_class=HTMLResponse)
def games_page(request: Request, user: str="demo"):
    with db() as c: rows=c.execute("SELECT * FROM games WHERE active=1 ORDER BY title").fetchall()
    return templates.TemplateResponse(request, "games.html", {"games":rows,"user":user})


@router.get("/game/{slug}", response_class=HTMLResponse)
def game_page(request: Request, slug: str, user: str="demo"):
    with db() as c: game=c.execute("SELECT * FROM games WHERE slug=? AND active=1",(slug,)).fetchone()
    if not game: raise HTTPException(404,"game not found")
    return templates.TemplateResponse(request, "game.html", {"game":game,"user":user})


def _challenge(slug: str, difficulty: int) -> tuple[str,list[str],str]:
    d=max(1,min(10,difficulty))
    if slug=="number-dash":
        top=10+d*8; a=random.randint(1,top); b=random.randint(1,top); op=random.choice(["+","-"] if d<5 else ["+","-","*"])
        if op=="+": ans=a+b
        elif op=="-": ans=a-b
        else: ans=a*b
        options={ans,ans+1,ans-1,ans+random.choice([2,3,5])}
        while len(options)<4: options.add(ans+random.randint(-9,9))
        opts=[str(x) for x in options]; random.shuffle(opts); return f"{a} {op} {b} = ?",opts,str(ans)
    if slug=="word-forge":
        word,answer=random.choice(VOCAB); wrong=[x[1] for x in VOCAB if x[1]!=answer]; opts=random.sample(wrong,3)+[answer]; random.shuffle(opts); return f"ما معنى {word}؟",opts,answer
    if slug=="science-orbit":
        obj,answer=random.choice(SCIENCE); opts=["planet","star","satellite","galaxy"]; random.shuffle(opts); return f"صنّف: {obj}",opts,answer
    raise HTTPException(404,"game not found")


@router.get("/api/games/{slug}/challenge")
def new_challenge(slug: str, user_id: str="demo") -> dict[str, Any]:
    with db() as c:
        g=c.execute("SELECT 1 FROM games WHERE slug=? AND active=1",(slug,)).fetchone()
        if not g: raise HTTPException(404,"game not found")
        p=c.execute("SELECT * FROM game_progress WHERE user_id=? AND game_slug=?",(user_id,slug)).fetchone(); rating=float(p["rating"]) if p else 1000
        difficulty=max(1,min(10,round((rating-800)/100)+2)); prompt,choices,answer=_challenge(slug,difficulty); cid=str(uuid.uuid4())
        c.execute("INSERT INTO game_challenges(id,user_id,game_slug,prompt,choices_json,answer,difficulty,created_at) VALUES(?,?,?,?,?,?,?,?)",(cid,user_id,slug,prompt,json.dumps(choices,ensure_ascii=False),answer,difficulty,now()))
    return {"challenge_id":cid,"prompt":prompt,"choices":choices,"difficulty":difficulty,"adaptive":True}


@router.post("/api/games/{slug}/submit")
def submit_game(slug: str, payload: dict[str, Any]) -> dict[str, Any]:
    uid=str(payload.get("user_id","demo")); cid=str(payload.get("challenge_id","")); answer=str(payload.get("answer",""))
    with db() as c:
        ch=c.execute("SELECT * FROM game_challenges WHERE id=? AND user_id=? AND game_slug=? AND answered_at IS NULL",(cid,uid,slug)).fetchone()
        if not ch: raise HTTPException(404,"active challenge not found")
        correct=int(answer.casefold()==str(ch["answer"]).casefold()); c.execute("UPDATE game_challenges SET answered_at=? WHERE id=?",(now(),cid))
        p=c.execute("SELECT * FROM game_progress WHERE user_id=? AND game_slug=?",(uid,slug)).fetchone(); rating=float(p["rating"]) if p else 1000; old_streak=int(p["streak"]) if p else 0
        new_rating=max(600,min(2000,rating+(18 if correct else -12))); streak=old_streak+1 if correct else 0; best=max(int(p["best_streak"]) if p else 0,streak)
        c.execute("INSERT INTO game_progress(user_id,game_slug,rating,correct,total,streak,best_streak) VALUES(?,?,?,?,?,?,?) ON CONFLICT(user_id,game_slug) DO UPDATE SET rating=excluded.rating,correct=game_progress.correct+?,total=game_progress.total+1,streak=excluded.streak,best_streak=excluded.best_streak",(uid,slug,new_rating,correct,1,streak,best,correct))
        comps=c.execute("SELECT id FROM learning_competitions WHERE game_slug=? AND active=1 AND start_at<=? AND end_at>=?",(slug,now(),now())).fetchall()
        for comp in comps:
            c.execute("INSERT INTO learning_competition_entries(competition_id,user_id,score,verified,updated_at) VALUES(?,?,?,?,?) ON CONFLICT(competition_id,user_id) DO UPDATE SET score=score+excluded.score,verified=1,updated_at=excluded.updated_at",(comp["id"],uid,1 if correct else 0,1,now()))
    reward=emit_economy_event(user_id=uid,event_type="verified_learning_game_correct",amount=2,asset="XP",metadata={"game":slug,"challenge_id":cid,"difficulty":ch["difficulty"]}) if correct else None
    return {"correct":bool(correct),"correct_answer":None if correct else ch["answer"],"rating":new_rating,"streak":streak,"reward":reward}


@router.get("/api/games/{slug}/progress/{user_id}")
def game_progress(slug: str,user_id: str) -> dict[str, Any]:
    with db() as c: p=c.execute("SELECT * FROM game_progress WHERE user_id=? AND game_slug=?",(user_id,slug)).fetchone()
    return dict(p) if p else {"user_id":user_id,"game_slug":slug,"rating":1000,"correct":0,"total":0,"streak":0,"best_streak":0}


@router.get("/api/learning-competitions/{slug}/leaderboard")
def comp_leaderboard(slug: str) -> dict[str, Any]:
    with db() as c:
        comp=c.execute("SELECT id,title,game_slug FROM learning_competitions WHERE slug=?",(slug,)).fetchone()
        if not comp: raise HTTPException(404,"competition not found")
        rows=c.execute("SELECT user_id,score,updated_at FROM learning_competition_entries WHERE competition_id=? AND verified=1 ORDER BY score DESC,updated_at LIMIT 100",(comp["id"],)).fetchall()
    return {"competition":dict(comp),"leaderboard":[{"rank":i+1,**dict(r)} for i,r in enumerate(rows)]}


@router.post("/api/proposals/{proposal_id}/vote")
def vote(proposal_id: int,payload: dict[str, Any]) -> dict[str, Any]:
    uid=str(payload.get("user_id","demo")); balances=_economy_balance(uid); thf=float(balances.get("THF_PENDING",0))
    with db() as c:
        p=c.execute("SELECT * FROM competition_proposals WHERE id=? AND status='voting'",(proposal_id,)).fetchone()
        if not p: raise HTTPException(404,"proposal not found")
        if thf<float(p["min_thf_balance"]): raise HTTPException(403,"token-holder eligibility required")
        # صوت واحد لكل حامل مؤهل. الرصيد لا يشتري mastery أو نتيجة المنافسة.
        weight=1.0; c.execute("INSERT INTO competition_votes(proposal_id,user_id,weight,created_at) VALUES(?,?,?,?)",(proposal_id,uid,weight,now()))
    return {"voted":True,"weight":1,"eligibility_asset":"THF_PENDING","pay_to_win":False}


@router.get("/api/ambassadors")
def ambassadors() -> dict[str, Any]:
    with db() as c: rows=c.execute("SELECT * FROM ambassadors WHERE active=1 ORDER BY verified DESC,display_name").fetchall()
    return {"items":[dict(r) for r in rows]}


@router.get("/api/ads/next-quest")
def next_ad(user_id: str="demo",placement: str="home_native",context: str="browsing") -> dict[str, Any]:
    if context in {"quiz","exam","game_round","review","child_focus"}: return {"ad":None,"reason":"learning_focus_protected"}
    with db() as c:
        rows=c.execute("SELECT * FROM quest_ad_campaigns WHERE enabled=1 AND placement=? ORDER BY id",(placement,)).fetchall()
        for r in rows:
            since=now()-86400; count=c.execute("SELECT COUNT(*) FROM quest_ad_events WHERE campaign_id=? AND user_id=? AND kind='impression' AND created_at>=?",(r["id"],user_id,since)).fetchone()[0]; last=c.execute("SELECT COALESCE(MAX(created_at),0) FROM quest_ad_events WHERE campaign_id=? AND user_id=?",(r["id"],user_id)).fetchone()[0]
            if count>=r["frequency_cap_day"] or now()-last<r["min_interval_sec"]: continue
            c.execute("INSERT INTO quest_ad_events(campaign_id,user_id,kind,created_at) VALUES(?,?,?,?)",(r["id"],user_id,"impression",now())); c.execute("UPDATE quest_ad_campaigns SET impressions=impressions+1 WHERE id=?",(r["id"],)); return {"ad":{"id":r["id"],"text":r["creative_text"],"url":r["landing_url"]}}
    return {"ad":None}


@router.put("/api/privacy/{user_id}")
def privacy(user_id: str,payload: dict[str, Any]) -> dict[str, Any]:
    with db() as c: c.execute("INSERT INTO quest_privacy(user_id,data_saver,public_progress,show_leaderboard_name,updated_at) VALUES(?,?,?,?,?) ON CONFLICT(user_id) DO UPDATE SET data_saver=excluded.data_saver,public_progress=excluded.public_progress,show_leaderboard_name=excluded.show_leaderboard_name,updated_at=excluded.updated_at",(user_id,1 if payload.get("data_saver") else 0,1 if payload.get("public_progress") else 0,1 if payload.get("show_leaderboard_name",True) else 0,now()))
    return {"saved":True,"data_saver":bool(payload.get("data_saver")),"learning_mastery_used_for_ads":False}


@router.get("/api/admin/quest-expansion")
def admin_expansion(x_admin_key: str=Header(default="")) -> dict[str, Any]:
    if not ADMIN_KEY or x_admin_key!=ADMIN_KEY: raise HTTPException(403,"forbidden")
    with db() as c:
        return {"ambassadors":[dict(r) for r in c.execute("SELECT * FROM ambassadors")],"games":[dict(r) for r in c.execute("SELECT * FROM games")],"competitions":[dict(r) for r in c.execute("SELECT * FROM learning_competitions")],"proposals":[dict(r) for r in c.execute("SELECT * FROM competition_proposals")],"ads":[dict(r) for r in c.execute("SELECT * FROM quest_ad_campaigns")]}


@router.post("/api/admin/ambassadors")
def admin_add_ambassador(payload: dict[str, Any],x_admin_key: str=Header(default="")) -> dict[str, Any]:
    if not ADMIN_KEY or x_admin_key!=ADMIN_KEY: raise HTTPException(403,"forbidden")
    handle=str(payload["handle"])
    with db() as c: c.execute("INSERT INTO ambassadors(handle,display_name,focus,bio,media_url,verified,active) VALUES(?,?,?,?,?,?,1)",(handle,payload["display_name"],payload.get("focus","general"),payload.get("bio",""),payload.get("media_url",f"{MEDIA_BASE_URL}/u/{handle}"),1 if payload.get("verified") else 0))
    return {"created":True}

@router.post("/api/admin/games")
def admin_add_game(payload: dict[str, Any],x_admin_key: str=Header(default="")) -> dict[str, Any]:
    if not ADMIN_KEY or x_admin_key!=ADMIN_KEY: raise HTTPException(403,"forbidden")
    kind=str(payload.get("kind","external"))
    if kind not in {"local","external"}: raise HTTPException(400,"bad kind")
    with db() as c:c.execute("INSERT INTO games(slug,title,category,description,launch_url,kind,active) VALUES(?,?,?,?,?,?,1)",(payload["slug"],payload["title"],payload.get("category","general"),payload.get("description",""),payload.get("launch_url","/games"),kind))
    return {"created":True}

@router.post("/api/admin/learning-competitions")
def admin_add_competition(payload: dict[str, Any],x_admin_key: str=Header(default="")) -> dict[str, Any]:
    if not ADMIN_KEY or x_admin_key!=ADMIN_KEY: raise HTTPException(403,"forbidden")
    with db() as c:
        if not c.execute("SELECT 1 FROM games WHERE slug=?",(payload["game_slug"],)).fetchone(): raise HTTPException(404,"game not found")
        c.execute("INSERT INTO learning_competitions(slug,title,game_slug,start_at,end_at,reward_xp,active) VALUES(?,?,?,?,?,?,1)",(payload["slug"],payload["title"],payload["game_slug"],int(payload.get("start_at",now())),int(payload.get("end_at",now()+7*86400)),float(payload.get("reward_xp",100))))
    return {"created":True}

@router.post("/api/admin/proposals")
def admin_add_proposal(payload: dict[str, Any],x_admin_key: str=Header(default="")) -> dict[str, Any]:
    if not ADMIN_KEY or x_admin_key!=ADMIN_KEY: raise HTTPException(403,"forbidden")
    with db() as c:
        cur=c.execute("INSERT INTO competition_proposals(title,description,created_by,status,min_thf_balance,created_at) VALUES(?,?,?,?,?,?)",(payload["title"],payload.get("description",""),payload.get("created_by","admin"),"voting",max(0,float(payload.get("min_thf_balance",1))),now()))
    return {"created":True,"id":cur.lastrowid}

@router.post("/api/admin/quest-ads")
def admin_add_ad(payload: dict[str, Any],x_admin_key: str=Header(default="")) -> dict[str, Any]:
    if not ADMIN_KEY or x_admin_key!=ADMIN_KEY: raise HTTPException(403,"forbidden")
    placement=str(payload.get("placement","home_native"))
    if placement not in {"home_native","course_native","community_native","games_lobby"}: raise HTTPException(400,"bad placement")
    with db() as c:
        cur=c.execute("INSERT INTO quest_ad_campaigns(name,placement,creative_text,landing_url,frequency_cap_day,min_interval_sec) VALUES(?,?,?,?,?,?)",(payload.get("name","Campaign"),placement,payload.get("creative_text",""),payload.get("landing_url",""),max(1,min(10,int(payload.get("frequency_cap_day",2)))),max(60,int(payload.get("min_interval_sec",1200)))))
    return {"created":True,"id":cur.lastrowid}
