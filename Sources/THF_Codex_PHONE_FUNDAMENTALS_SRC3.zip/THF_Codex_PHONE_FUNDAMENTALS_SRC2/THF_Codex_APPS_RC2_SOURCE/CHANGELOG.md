# Changelog
## 2.0.0
- Rebrand standalone Learn as THF Codex.
- Add ambassadors linked to THF Link, learning competitions and token-holder proposal voting.
- Add Number Dash, Word Forge and Science Orbit as playable animated HTML5 game loops.
- Keep challenge answer, adaptive difficulty, progress, competition score and rewards server-authoritative.
- Add privacy/data saver and focus-protected ads.
