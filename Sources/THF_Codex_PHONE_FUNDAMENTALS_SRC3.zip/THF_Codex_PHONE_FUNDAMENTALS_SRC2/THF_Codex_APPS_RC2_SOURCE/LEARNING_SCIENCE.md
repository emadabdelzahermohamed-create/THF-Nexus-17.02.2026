# Learning science layer

يعتمد التصميم على مبدأين عامين معروفين في علم التعلم:
- Retrieval practice: جعل المتعلم يسترجع الإجابة بدل القراءة فقط.
- Spaced practice: توزيع المراجعة على الزمن بدل الحفظ المكثف في جلسة واحدة.

الخوارزمية الحالية للمراجعة مبسطة على نمط SM-2، وهي قابلة للاستبدال لاحقًا بمحرك إتقان أكثر تطورًا دون تغيير API.

## مراجع مباشرة
- Roediger & Karpicke (2006), *Test-Enhanced Learning: Taking Memory Tests Improves Long-Term Retention*, Psychological Science. DOI: https://doi.org/10.1111/j.1467-9280.2006.01693.x
- Cepeda et al. (2006), *Distributed practice in verbal recall tasks: A review and quantitative synthesis*, Psychological Bulletin. DOI: https://doi.org/10.1037/0033-2909.132.3.354

محرك الألعاب التكيفي في V2 يغيّر مستوى صعوبة الأسئلة وفق rating محفوظ ويستخدم الاسترجاع النشط داخل جولات قصيرة. الـrating هنا أداة تكييف للخبرة وليس قياسًا نفسيًا معياريًا، ولا يتم شراء mastery أو إجابة صحيحة بالعملة.
