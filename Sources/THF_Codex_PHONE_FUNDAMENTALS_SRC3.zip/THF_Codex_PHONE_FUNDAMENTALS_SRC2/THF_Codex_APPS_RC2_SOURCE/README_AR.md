# THF Codex 2.0 — Learning Standalone

تطبيق تعليمي مستقل ببايثون/FastAPI وقاعدة SQLite مستقلة. الاتصال الوحيد الاختياري مع THF هو Economy API.

## الخصائص
- Courses / Lessons / Questions / Progress.
- مسارات أولية: Python، English، Science، Financial Literacy.
- Quiz attempts وMastery foundation.
- Spaced repetition queue.
- Streaks وDaily/Weekly quests وLeaderboard.
- مكافآت XP لأول إكمال فقط؛ لا يمكن شراء mastery أو نجاح الاختبار.
- Admin منفصل عن learner UI.

## تشغيل
```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
set -a; source .env; set +a
pytest -q
./run.sh
```
افتح `http://localhost:8103`.

## THF Codex 2.0
- الاسم الجديد: **THF Codex**.
- سفراء بملف مختصر داخل التطبيق ورابط ملف كامل على THF Link.
- مسابقات تعليمية وقوائم ترتيب من نتائج ألعاب يتحقق منها الخادم.
- اقتراحات مسابقات يمكن لحامل THF المؤهل التصويت عليها عبر Economy؛ الصوت لا يشتري mastery أو ترتيباً.
- ثلاث ألعاب HTML5 محلية حقيقية كبداية: Number Dash وWord Forge وScience Orbit؛ كل جولة لها challenge server-side وصعوبة تكيفية وتقدم محفوظ.
- البنية تسمح بربط ألعاب تعليمية مستقلة أخرى عبر game registry بدون إدخالها في قاعدة بيانات التطبيق.
- Data Saver/Privacy وإعلانات ممنوعة أثناء quiz/exam/game round/review.
