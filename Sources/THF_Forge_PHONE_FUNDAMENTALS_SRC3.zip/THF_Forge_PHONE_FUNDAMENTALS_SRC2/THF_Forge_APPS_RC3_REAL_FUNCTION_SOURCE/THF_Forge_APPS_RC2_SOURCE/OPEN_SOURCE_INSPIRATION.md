# Open-source inspiration
- Medusa core — MIT/open-core: commerce modules, products, promotions, admin API patterns.
- Django Oscar — BSD: catalogue/basket/order/offer concepts.
- Saleor — used as architecture/UI research only; no copied code.

THF Forge implementation in this package was written independently in Python/FastAPI.
