# THF Forge Phone Fundamentals V2

- Derived only from authoritative Phone Fundamentals V1 exact source.
- Adds first-run onboarding and explicit account/logout/delete call sites without placeholder endpoints.
- Identity actions require configured trusted HTTPS and fail closed offline/unconfigured.
- Preserves package ID, API 36, RTL/20-locale resources, adaptive/monochrome/store icons.
- Private Signal/Command require THF Pass handoff plus server-returned authenticated subject/role claims before functional UI.
- No production OAuth/push/signing/device claim. No FINAL/PLAY_READY claim.
