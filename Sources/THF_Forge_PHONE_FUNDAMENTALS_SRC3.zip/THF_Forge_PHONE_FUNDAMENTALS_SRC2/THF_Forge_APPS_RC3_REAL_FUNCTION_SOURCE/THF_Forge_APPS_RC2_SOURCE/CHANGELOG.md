# Changelog
## 1.0.0
- New standalone Python/FastAPI commerce app.
- Vendors, physical/digital products, gym subscriptions, carts, orders, coupons and reviews.
- Signed Economy debit checkout with idempotent external ledger boundary.
- Admin control plane, privacy/data saver preference and protected-context native ads.
