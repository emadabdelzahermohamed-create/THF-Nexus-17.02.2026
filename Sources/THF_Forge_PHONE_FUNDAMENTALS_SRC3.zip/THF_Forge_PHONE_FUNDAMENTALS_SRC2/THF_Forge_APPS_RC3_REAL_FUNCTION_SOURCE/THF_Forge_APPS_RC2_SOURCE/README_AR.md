# THF Forge 1.0

تطبيق متجر مستقل ببايثون/FastAPI وSQLite. يدعم vendors، المنتجات المادية والرقمية، اشتراكات الجيمات، السلة، الطلبات، الخصومات، المراجعات، الإعلانات والـAdmin Control Plane.

الربط المالي الوحيد هو Economy API؛ المتجر لا يقوم بـmint أو توقيع تحويل on-chain. روابط البائعين إلى THF Link روابط واجهة فقط ولا توجد قاعدة بيانات مشتركة.

## تشغيل
```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
set -a; source .env; set +a
pytest -q
./run.sh
```
