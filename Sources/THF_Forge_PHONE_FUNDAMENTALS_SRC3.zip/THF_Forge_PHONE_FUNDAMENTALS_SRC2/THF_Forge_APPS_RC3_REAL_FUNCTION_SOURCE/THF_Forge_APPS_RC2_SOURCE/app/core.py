from __future__ import annotations

import hashlib,hmac,json,os,sqlite3,time,uuid
from contextlib import contextmanager
from pathlib import Path
from typing import Any
import httpx

DB_PATH=Path(os.getenv('DB_PATH','./data/market.db'))
ADMIN_KEY=os.getenv('ADMIN_KEY','').strip()
ECONOMY_URL=os.getenv('ECONOMY_URL','').rstrip('/')
ECONOMY_SERVICE=os.getenv('ECONOMY_SERVICE','market')
ECONOMY_SERVICE_SECRET=os.getenv('ECONOMY_SERVICE_SECRET','').strip()
MEDIA_BASE_URL=os.getenv('MEDIA_BASE_URL','').strip().rstrip('/')

def now()->int:return int(time.time())
@contextmanager
def db():
    DB_PATH.parent.mkdir(parents=True,exist_ok=True); c=sqlite3.connect(DB_PATH); c.row_factory=sqlite3.Row; c.execute('PRAGMA foreign_keys=ON')
    try:yield c;c.commit()
    finally:c.close()

def _sign(payload:dict[str,Any])->str:
    raw=json.dumps(payload,sort_keys=True,separators=(',',':')).encode(); return hmac.new(ECONOMY_SERVICE_SECRET.encode(),raw,hashlib.sha256).hexdigest()

def debit_economy(*,user_id:str,amount:float,asset:str,order_id:str)->dict[str,Any]:
    """طلب خصم من بوابة الاقتصاد. المتجر لا يوقّع تحويلات بلوكشين بنفسه."""
    payload={'event_id':str(uuid.uuid4()),'service':ECONOMY_SERVICE,'user_id':user_id,'event_type':'market_checkout','asset':asset,'amount':float(amount),'metadata':{'order_id':order_id},'ts':now()}
    status='pending'; gateway={}
    if ECONOMY_URL.startswith("https://") and ECONOMY_SERVICE_SECRET:
        try:
            r=httpx.post(f'{ECONOMY_URL}/debits',json=payload,headers={'X-THF-Signature':_sign(payload)},timeout=5); r.raise_for_status();gateway=r.json();status='sent'
        except Exception as exc:gateway={'error':type(exc).__name__}
    with db() as c:c.execute('INSERT INTO economy_outbox(event_id,payload_json,status,created_at) VALUES(?,?,?,?)',(payload['event_id'],json.dumps(payload,ensure_ascii=False),status,now()))
    return {'status':status,'gateway':gateway,'event':payload}
