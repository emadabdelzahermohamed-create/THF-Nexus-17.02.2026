from __future__ import annotations

import json,uuid
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any
from fastapi import FastAPI,Header,HTTPException,Request
from fastapi.responses import HTMLResponse,RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from .core import ADMIN_KEY,MEDIA_BASE_URL,db,debit_economy,now

BASE=Path(__file__).resolve().parent.parent


def init_db():
    with db() as c:
        c.executescript('''
        CREATE TABLE IF NOT EXISTS vendors(id INTEGER PRIMARY KEY AUTOINCREMENT,slug TEXT UNIQUE,name TEXT,kind TEXT,bio TEXT,media_url TEXT,verified INTEGER DEFAULT 0,active INTEGER DEFAULT 1);
        CREATE TABLE IF NOT EXISTS products(id INTEGER PRIMARY KEY AUTOINCREMENT,slug TEXT UNIQUE,title TEXT,description TEXT,category TEXT,product_type TEXT,vendor_id INTEGER,price REAL,asset TEXT,inventory INTEGER DEFAULT 0,recurring_months INTEGER DEFAULT 0,image_url TEXT,active INTEGER DEFAULT 1,FOREIGN KEY(vendor_id) REFERENCES vendors(id));
        CREATE TABLE IF NOT EXISTS carts(id TEXT PRIMARY KEY,user_id TEXT,status TEXT DEFAULT 'open',created_at INTEGER,updated_at INTEGER);
        CREATE TABLE IF NOT EXISTS cart_items(id INTEGER PRIMARY KEY AUTOINCREMENT,cart_id TEXT,product_id INTEGER,qty INTEGER,unit_price REAL,asset TEXT,UNIQUE(cart_id,product_id),FOREIGN KEY(cart_id) REFERENCES carts(id) ON DELETE CASCADE,FOREIGN KEY(product_id) REFERENCES products(id));
        CREATE TABLE IF NOT EXISTS orders(id TEXT PRIMARY KEY,user_id TEXT,status TEXT,total REAL,asset TEXT,created_at INTEGER,paid_at INTEGER,coupon_code TEXT);
        CREATE TABLE IF NOT EXISTS order_items(id INTEGER PRIMARY KEY AUTOINCREMENT,order_id TEXT,product_id INTEGER,title TEXT,qty INTEGER,unit_price REAL,FOREIGN KEY(order_id) REFERENCES orders(id) ON DELETE CASCADE);
        CREATE TABLE IF NOT EXISTS subscriptions(id TEXT PRIMARY KEY,user_id TEXT,product_id INTEGER,order_id TEXT,status TEXT,starts_at INTEGER,ends_at INTEGER,FOREIGN KEY(product_id) REFERENCES products(id));
        CREATE TABLE IF NOT EXISTS coupons(code TEXT PRIMARY KEY,percent_off REAL,max_uses INTEGER,used INTEGER DEFAULT 0,active INTEGER DEFAULT 1);
        CREATE TABLE IF NOT EXISTS reviews(id INTEGER PRIMARY KEY AUTOINCREMENT,product_id INTEGER,user_id TEXT,rating INTEGER,body TEXT,status TEXT DEFAULT 'visible',created_at INTEGER,UNIQUE(product_id,user_id));
        CREATE TABLE IF NOT EXISTS market_ads(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,placement TEXT,creative_text TEXT,landing_url TEXT,enabled INTEGER DEFAULT 1,frequency_cap_day INTEGER DEFAULT 3,min_interval_sec INTEGER DEFAULT 900,impressions INTEGER DEFAULT 0);
        CREATE TABLE IF NOT EXISTS market_ad_events(id INTEGER PRIMARY KEY AUTOINCREMENT,campaign_id INTEGER,user_id TEXT,kind TEXT,created_at INTEGER);
        CREATE TABLE IF NOT EXISTS privacy_settings(user_id TEXT PRIMARY KEY,data_saver INTEGER DEFAULT 0,personalized_ads INTEGER DEFAULT 0,updated_at INTEGER);
        CREATE TABLE IF NOT EXISTS economy_outbox(event_id TEXT PRIMARY KEY,payload_json TEXT,status TEXT,created_at INTEGER);
        ''')
        if c.execute('SELECT COUNT(*) FROM vendors').fetchone()[0]==0:
            c.executemany('INSERT INTO vendors(slug,name,kind,bio,media_url,verified) VALUES(?,?,?,?,?,?)',[
                ('hero-gym-cairo','Hero Gym Cairo','gym','اشتراكات جيم وخدمات تدريب.',f'{MEDIA_BASE_URL}/u/hero-gym-cairo',1),
                ('thf-official','THF Official','platform','منتجات وخدمات THF الرسمية.',f'{MEDIA_BASE_URL}/u/thf-official',1),
                ('creator-lina','Lina Creator','creator','منتجات رقمية تعليمية.',f'{MEDIA_BASE_URL}/u/ambassador-lina',1),
            ])
        if c.execute('SELECT COUNT(*) FROM products').fetchone()[0]==0:
            vids={r['slug']:r['id'] for r in c.execute('SELECT id,slug FROM vendors')}
            rows=[
              ('hero-gym-monthly','Hero Gym — اشتراك شهر','اشتراك شهر في الجيم الشريك مع مزايا مسابقات وتسجيل حضور.','gym','gym_membership',vids['hero-gym-cairo'],900,'CREDITS',999,1,'',1),
              ('hero-gym-quarter','Hero Gym — 3 أشهر','اشتراك ربع سنوي بسعر أفضل.','gym','gym_membership',vids['hero-gym-cairo'],2400,'CREDITS',999,3,'',1),
              ('pulse-training-pack','THF Pulse Training Pack','حزمة رقمية إضافية لبرامج تدريب متقدمة.','digital','digital_service',vids['thf-official'],350,'CREDITS',9999,0,'',1),
              ('quest-stem-pack','Codex STEM Pack','حزمة محتوى وألعاب STEM تعليمية.','education','digital_service',vids['creator-lina'],220,'CREDITS',9999,0,'',1),
              ('thf-performance-shirt','THF Performance Shirt','قطعة ملابس رياضية فعلية كمثال لكتالوج السلع المادية.','apparel','physical',vids['thf-official'],650,'CREDITS',100,0,'',1),
            ]
            c.executemany('INSERT INTO products(slug,title,description,category,product_type,vendor_id,price,asset,inventory,recurring_months,image_url,active) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',rows)
        if c.execute('SELECT COUNT(*) FROM coupons').fetchone()[0]==0:c.execute('INSERT INTO coupons(code,percent_off,max_uses) VALUES(?,?,?)',('WELCOME10',10,1000))
        if c.execute('SELECT COUNT(*) FROM market_ads').fetchone()[0]==0:c.execute('INSERT INTO market_ads(name,placement,creative_text,landing_url) VALUES(?,?,?,?)',('Partner Spotlight','browse_native','شريك موثّق — موضع إعلاني أصلي غير مزعج','/'))

@asynccontextmanager
async def lifespan(app:FastAPI):init_db();yield
app=FastAPI(title='THF Forge',version='2.1.0-stage16o',lifespan=lifespan)
app.mount('/static',StaticFiles(directory=BASE/'static'),name='static')
templates=Jinja2Templates(directory=BASE/'templates')

@app.get('/health')
def health():return {'ok':True,'service':'THF Forge','version':'1.0.0','economy_service':'market','onchain_settlement':False}

@app.get('/',response_class=HTMLResponse)
def home(request:Request,user:str='demo',category:str=''):
    with db() as c:
        if category:products=c.execute('SELECT p.*,v.name vendor_name,v.verified vendor_verified FROM products p JOIN vendors v ON v.id=p.vendor_id WHERE p.active=1 AND p.category=? ORDER BY p.id DESC',(category,)).fetchall()
        else:products=c.execute('SELECT p.*,v.name vendor_name,v.verified vendor_verified FROM products p JOIN vendors v ON v.id=p.vendor_id WHERE p.active=1 ORDER BY p.id DESC').fetchall()
        categories=[r[0] for r in c.execute('SELECT DISTINCT category FROM products WHERE active=1 ORDER BY category')]
    return templates.TemplateResponse(request, 'home.html', {'products':products,'categories':categories,'user':user})

@app.get('/product/{slug}',response_class=HTMLResponse)
def product_page(request:Request,slug:str,user:str='demo'):
    with db() as c:
        p=c.execute('SELECT p.*,v.name vendor_name,v.media_url vendor_media,v.verified vendor_verified FROM products p JOIN vendors v ON v.id=p.vendor_id WHERE p.slug=? AND p.active=1',(slug,)).fetchone(); reviews=c.execute('SELECT * FROM reviews WHERE product_id=(SELECT id FROM products WHERE slug=?) AND status="visible" ORDER BY created_at DESC LIMIT 50',(slug,)).fetchall()
    if not p:raise HTTPException(404,'product not found')
    return templates.TemplateResponse(request, 'product.html', {'product':p,'reviews':reviews,'user':user})

@app.get('/gym/{slug}')
def gym_redirect(slug:str):
    with db() as c:p=c.execute("SELECT p.slug FROM products p JOIN vendors v ON v.id=p.vendor_id WHERE v.slug=? AND p.active=1 ORDER BY p.recurring_months LIMIT 1",(slug,)).fetchone()
    if not p:raise HTTPException(404,'gym product not found')
    return RedirectResponse('/product/'+p['slug'],302)

def _open_cart(c,user_id:str):
    row=c.execute("SELECT * FROM carts WHERE user_id=? AND status='open' ORDER BY created_at DESC LIMIT 1",(user_id,)).fetchone()
    if row:return row['id']
    cid=str(uuid.uuid4());c.execute('INSERT INTO carts(id,user_id,status,created_at,updated_at) VALUES(?,?,?,?,?)',(cid,user_id,'open',now(),now()));return cid

@app.post('/api/cart/add')
def cart_add(payload:dict[str,Any]):
    uid=str(payload.get('user_id','demo'));slug=str(payload.get('slug',''));qty=max(1,min(20,int(payload.get('qty',1))))
    with db() as c:
        p=c.execute('SELECT * FROM products WHERE slug=? AND active=1',(slug,)).fetchone()
        if not p:raise HTTPException(404,'product not found')
        if p['inventory']<qty:raise HTTPException(409,'insufficient inventory')
        cid=_open_cart(c,uid);existing=c.execute('SELECT qty FROM cart_items WHERE cart_id=? AND product_id=?',(cid,p['id'])).fetchone();new_qty=(existing['qty'] if existing else 0)+qty
        if new_qty>p['inventory']:raise HTTPException(409,'insufficient inventory')
        c.execute('INSERT INTO cart_items(cart_id,product_id,qty,unit_price,asset) VALUES(?,?,?,?,?) ON CONFLICT(cart_id,product_id) DO UPDATE SET qty=excluded.qty,unit_price=excluded.unit_price,asset=excluded.asset',(cid,p['id'],new_qty,p['price'],p['asset']));c.execute('UPDATE carts SET updated_at=? WHERE id=?',(now(),cid))
    return {'cart_id':cid,'added':True}

@app.get('/cart',response_class=HTMLResponse)
def cart_page(request:Request,user:str='demo'):
    with db() as c:
        cid=_open_cart(c,user);items=c.execute('SELECT ci.*,p.title,p.slug FROM cart_items ci JOIN products p ON p.id=ci.product_id WHERE ci.cart_id=?',(cid,)).fetchall()
    assets={r['asset'] for r in items};total=sum(r['qty']*r['unit_price'] for r in items) if len(assets)<=1 else 0
    return templates.TemplateResponse(request, 'cart.html', {'items':items,'cart_id':cid,'total':total,'asset':next(iter(assets),'CREDITS'),'mixed_assets':len(assets)>1,'user':user})

@app.post('/api/checkout')
def checkout(payload:dict[str,Any]):
    uid=str(payload.get('user_id','demo'));coupon=str(payload.get('coupon','')).strip().upper()
    with db() as c:
        cart=c.execute("SELECT * FROM carts WHERE user_id=? AND status='open' ORDER BY created_at DESC LIMIT 1",(uid,)).fetchone()
        if not cart:raise HTTPException(404,'cart not found')
        items=c.execute('SELECT ci.*,p.title,p.inventory,p.product_type,p.recurring_months FROM cart_items ci JOIN products p ON p.id=ci.product_id WHERE ci.cart_id=?',(cart['id'],)).fetchall()
        if not items:raise HTTPException(400,'empty cart')
        assets={r['asset'] for r in items}
        if len(assets)!=1:raise HTTPException(400,'one asset per checkout required')
        for i in items:
            if i['qty']>i['inventory']:raise HTTPException(409,'inventory changed')
        total=sum(i['qty']*i['unit_price'] for i in items);discount=0.0
        if coupon:
            cp=c.execute('SELECT * FROM coupons WHERE code=? AND active=1 AND used<max_uses',(coupon,)).fetchone()
            if cp:discount=total*float(cp['percent_off'])/100
        total=round(max(0,total-discount),2);asset=next(iter(assets));oid=str(uuid.uuid4())
        c.execute('INSERT INTO orders(id,user_id,status,total,asset,created_at,coupon_code) VALUES(?,?,?,?,?,?,?)',(oid,uid,'awaiting_economy',total,asset,now(),coupon or None))
        for i in items:c.execute('INSERT INTO order_items(order_id,product_id,title,qty,unit_price) VALUES(?,?,?,?,?)',(oid,i['product_id'],i['title'],i['qty'],i['unit_price']))
    debit=debit_economy(user_id=uid,amount=total,asset=asset,order_id=oid)
    accepted=debit['status']=='sent' and debit.get('gateway',{}).get('accepted') is True
    with db() as c:
        if accepted:
            c.execute("UPDATE orders SET status='paid',paid_at=? WHERE id=?",(now(),oid));c.execute("UPDATE carts SET status='checked_out',updated_at=? WHERE id=?",(now(),cart['id']))
            for i in items:
                c.execute('UPDATE products SET inventory=inventory-? WHERE id=?',(i['qty'],i['product_id']))
                if i['recurring_months']>0:
                    sid=str(uuid.uuid4());c.execute('INSERT INTO subscriptions(id,user_id,product_id,order_id,status,starts_at,ends_at) VALUES(?,?,?,?,?,?,?)',(sid,uid,i['product_id'],oid,'active',now(),now()+int(i['recurring_months'])*30*86400))
            if coupon:c.execute('UPDATE coupons SET used=used+1 WHERE code=?',(coupon,))
    return {'order_id':oid,'status':'paid' if accepted else 'awaiting_economy','total':total,'asset':asset,'discount':round(discount,2),'economy':debit}

@app.post('/api/reviews/{slug}')
def review(slug:str,payload:dict[str,Any]):
    uid=str(payload.get('user_id','demo'));rating=max(1,min(5,int(payload.get('rating',5))));body=str(payload.get('body',''))[:1000]
    with db() as c:
        p=c.execute('SELECT id FROM products WHERE slug=?',(slug,)).fetchone()
        if not p:raise HTTPException(404,'not found')
        c.execute('INSERT INTO reviews(product_id,user_id,rating,body,created_at) VALUES(?,?,?,?,?) ON CONFLICT(product_id,user_id) DO UPDATE SET rating=excluded.rating,body=excluded.body,created_at=excluded.created_at',(p['id'],uid,rating,body,now()))
    return {'saved':True}

@app.get('/api/ads/next')
def next_ad(user_id:str='demo',placement:str='browse_native',context:str='browse'):
    if context in {'cart','checkout','payment','support'}:return {'ad':None,'reason':'commerce_focus_protected'}
    with db() as c:
        rows=c.execute('SELECT * FROM market_ads WHERE enabled=1 AND placement=? ORDER BY id',(placement,)).fetchall()
        for r in rows:
            since=now()-86400;count=c.execute("SELECT COUNT(*) FROM market_ad_events WHERE campaign_id=? AND user_id=? AND kind='impression' AND created_at>=?",(r['id'],user_id,since)).fetchone()[0];last=c.execute('SELECT COALESCE(MAX(created_at),0) FROM market_ad_events WHERE campaign_id=? AND user_id=?',(r['id'],user_id)).fetchone()[0]
            if count>=r['frequency_cap_day'] or now()-last<r['min_interval_sec']:continue
            c.execute('INSERT INTO market_ad_events(campaign_id,user_id,kind,created_at) VALUES(?,?,?,?)',(r['id'],user_id,'impression',now()));c.execute('UPDATE market_ads SET impressions=impressions+1 WHERE id=?',(r['id'],));return {'ad':{'id':r['id'],'text':r['creative_text'],'url':r['landing_url']}}
    return {'ad':None}

@app.put('/api/privacy/{user_id}')
def privacy(user_id:str,payload:dict[str,Any]):
    with db() as c:c.execute('INSERT INTO privacy_settings(user_id,data_saver,personalized_ads,updated_at) VALUES(?,?,?,?) ON CONFLICT(user_id) DO UPDATE SET data_saver=excluded.data_saver,personalized_ads=excluded.personalized_ads,updated_at=excluded.updated_at',(user_id,1 if payload.get('data_saver') else 0,1 if payload.get('personalized_ads') else 0,now()))
    return {'saved':True,'sensitive_health_or_learning_data_used_for_ads':False}

@app.get('/admin',response_class=HTMLResponse)
def admin_page(request:Request):return templates.TemplateResponse(request, 'admin.html', {})
@app.get('/api/admin/dashboard')
def admin_dashboard(x_admin_key:str=Header(default='')):
    if not ADMIN_KEY or x_admin_key!=ADMIN_KEY:raise HTTPException(403,'forbidden')
    with db() as c:return {'products':[dict(r) for r in c.execute('SELECT * FROM products ORDER BY id')],'vendors':[dict(r) for r in c.execute('SELECT * FROM vendors ORDER BY id')],'orders':[dict(r) for r in c.execute('SELECT * FROM orders ORDER BY created_at DESC LIMIT 200')],'subscriptions':[dict(r) for r in c.execute('SELECT * FROM subscriptions ORDER BY starts_at DESC LIMIT 200')],'ads':[dict(r) for r in c.execute('SELECT * FROM market_ads')]}
@app.post('/api/admin/products')
def admin_add_product(payload:dict[str,Any],x_admin_key:str=Header(default='')):
    if not ADMIN_KEY or x_admin_key!=ADMIN_KEY:raise HTTPException(403,'forbidden')
    with db() as c:
        v=c.execute('SELECT id FROM vendors WHERE slug=?',(payload['vendor_slug'],)).fetchone()
        if not v:raise HTTPException(400,'vendor not found')
        c.execute('INSERT INTO products(slug,title,description,category,product_type,vendor_id,price,asset,inventory,recurring_months,image_url,active) VALUES(?,?,?,?,?,?,?,?,?,?,?,1)',(payload['slug'],payload['title'],payload.get('description',''),payload.get('category','general'),payload.get('product_type','physical'),v['id'],float(payload.get('price',0)),payload.get('asset','CREDITS'),int(payload.get('inventory',0)),int(payload.get('recurring_months',0)),payload.get('image_url','')))
    return {'created':True}

@app.post('/api/admin/vendors')
def admin_add_vendor(payload:dict[str,Any],x_admin_key:str=Header(default='')):
    if not ADMIN_KEY or x_admin_key!=ADMIN_KEY:raise HTTPException(403,'forbidden')
    with db() as c:
        cur=c.execute('INSERT INTO vendors(slug,name,kind,bio,media_url,verified,active) VALUES(?,?,?,?,?,?,1)',(payload['slug'],payload['name'],payload.get('kind','merchant'),payload.get('bio',''),payload.get('media_url',f"{MEDIA_BASE_URL}/u/{payload['slug']}"),1 if payload.get('verified') else 0))
    return {'created':True,'id':cur.lastrowid}

@app.post('/api/admin/ads')
def admin_add_ad(payload:dict[str,Any],x_admin_key:str=Header(default='')):
    if not ADMIN_KEY or x_admin_key!=ADMIN_KEY:raise HTTPException(403,'forbidden')
    placement=str(payload.get('placement','browse_native'))
    if placement not in {'browse_native','product_native','search_native'}:raise HTTPException(400,'bad placement')
    with db() as c:
        cur=c.execute('INSERT INTO market_ads(name,placement,creative_text,landing_url,frequency_cap_day,min_interval_sec) VALUES(?,?,?,?,?,?)',(payload.get('name','Campaign'),placement,payload.get('creative_text',''),payload.get('landing_url',''),max(1,min(10,int(payload.get('frequency_cap_day',3)))),max(60,int(payload.get('min_interval_sec',900)))))
    return {'created':True,'id':cur.lastrowid}


@app.middleware("http")
async def thf_security_headers(request, call_next):
    # رؤوس أمان أساسية؛ لا نضع CSP صارمة هنا لأن الواجهة المحلية تحتوي سكربتات inline.
    response = await call_next(request)
    response.headers.setdefault("X-Content-Type-Options", "nosniff")
    response.headers.setdefault("X-Frame-Options", "SAMEORIGIN")
    response.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
    response.headers.setdefault("Permissions-Policy", "camera=(self), microphone=(self), geolocation=(self)")
    if request.url.path.startswith("/admin") or request.url.path.startswith("/api/admin"):
        response.headers["Cache-Control"] = "no-store"
    return response


# Stage16-O THF Pass federation hook
import os as _thf_os
import httpx as _thf_httpx
from fastapi import Header as _ThfHeader, HTTPException as _ThfHTTPException
_THPASS=_thf_os.getenv("THF_PASS_URL","").strip().rstrip("/")
def _thpass_ready(): return _THPASS.startswith("https://")
@app.get("/api/thf-pass/registry")
async def thf_pass_registry():
    if not _thpass_ready(): raise _ThfHTTPException(503,"thf_pass_not_configured")
    try:
        async with _thf_httpx.AsyncClient(timeout=4) as c:
            r=await c.get(_THPASS+"/api/registry")
        if r.status_code!=200: raise _ThfHTTPException(503,"thf_pass_unavailable")
        return r.json()
    except _ThfHTTPException: raise
    except Exception: raise _ThfHTTPException(503,"thf_pass_unavailable")
@app.post("/api/thf-pass/handoff/{target}")
async def thf_pass_handoff(target:str,authorization:str|None=_ThfHeader(default=None)):
    if not _thpass_ready(): raise _ThfHTTPException(503,"thf_pass_not_configured")
    if not authorization or not authorization.lower().startswith("bearer "):
        raise _ThfHTTPException(401,"thf_pass_session_required")
    try:
        async with _thf_httpx.AsyncClient(timeout=4) as c:
            r=await c.post(_THPASS+f"/api/handoff/{target}",headers={"Authorization":authorization})
        if r.status_code!=200: raise _ThfHTTPException(r.status_code,"handoff_rejected")
        return r.json()
    except _ThfHTTPException: raise
    except Exception: raise _ThfHTTPException(503,"thf_pass_unavailable")
