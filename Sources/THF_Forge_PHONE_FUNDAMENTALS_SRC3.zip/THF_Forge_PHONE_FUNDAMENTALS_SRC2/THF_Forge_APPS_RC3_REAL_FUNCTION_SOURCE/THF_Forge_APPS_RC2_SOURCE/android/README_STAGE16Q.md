# THF Forge Android host — Stage16-Q

Final application ID: `com.topherofit.thf.forge`
Target/compile SDK: 36; minimum SDK: 26.
Visibility: PUBLIC.

This host intentionally fails closed when `THF_BASE_URL` is absent or not HTTPS. Provide release endpoints as Gradle properties, never hard-code secrets. THF Pass handoffs use the `topherofit://pass/handoff?target=forge&ticket=...` deep link and a separately injected HTTPS `THF_PASS_URL`. No bearer/session secret is embedded in source.

Build prerequisites: Android SDK platform 36, build-tools, Gradle/AGP dependencies, JDK 17+. This checkpoint does not claim a signed AAB.
