# THF Forge — APPS-RC3 Real-Function Hardening

This cumulative source checkpoint supersedes the APPS-RC2 source for the same app while preserving product/backend code, API 36 identity, 20-language native resources and RTL.

Hardening in this checkpoint:
- Android WebView disables third-party cookies.
- Data Saver no longer silently substitutes stale WebView network cache for authoritative server state; image loading remains reduced.
- HTTPS endpoint validation parses scheme/host and rejects user-info/malformed targets.
- THF Pass and cross-service handoffs fail closed when a required HTTPS endpoint is absent.
- Loopback development URLs are not runtime defaults for network-required product flows.
- Admin/economy secrets are explicit configuration; shipped `change-*` credential defaults are removed.
- Economy network submission requires both HTTPS endpoint and explicit service secret; otherwise the local outbox remains pending instead of pretending remote success.

Truth boundary: source engineering and local regression only. This file is NOT FINAL/PLAY_READY evidence. Exact APK package inspection, reachable deployed backend/auth, and physical-device install/launch/touch/layout/background-resume/offline-network/core-journey/crash-free evidence remain required.
