import os
os.environ.setdefault('DB_PATH','/tmp/thf-market-test.db')
os.environ.setdefault('ADMIN_KEY','test-admin')
from fastapi.testclient import TestClient
from app.main import app


def test_catalog_cart_admin_and_protected_ads():
    with TestClient(app) as c:
        assert c.get('/health').json()['version']=='1.0.0'
        assert c.get('/').status_code==200
        assert c.get('/product/hero-gym-monthly').status_code==200
        a=c.post('/api/cart/add',json={'user_id':'u','slug':'hero-gym-monthly','qty':1});assert a.status_code==200
        assert c.get('/cart',params={'user':'u'}).status_code==200
        assert c.get('/api/ads/next',params={'context':'checkout'}).json()['ad'] is None
        assert c.get('/api/admin/dashboard',headers={'X-Admin-Key':'bad'}).status_code==403
        assert c.get('/api/admin/dashboard',headers={'X-Admin-Key':'test-admin'}).status_code==200
